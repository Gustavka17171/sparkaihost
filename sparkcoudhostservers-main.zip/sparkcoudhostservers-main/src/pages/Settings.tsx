import { Layout } from "@/components/Layout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Key, Bell } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";

export default function Settings() {
  const { accessKey, isAdmin } = useAuth();

  const handleSave = () => {
    toast.success("Configurações salvas com sucesso!");
  };

  return (
    <Layout>
      <div className="space-y-6 max-w-3xl">
        {/* Header */}
        <div className="animate-slide-up">
          <h1 className="text-2xl lg:text-3xl font-bold">Configurações</h1>
          <p className="text-muted-foreground mt-1">
            Gerencie suas preferências
          </p>
        </div>

        {/* Access Key Info */}
        <div className="glass-card p-6 space-y-6 animate-fade-in">
          <div className="flex items-center gap-3 pb-4 border-b border-border">
            <div className="p-2 rounded-lg bg-primary/20">
              <Key className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h2 className="font-semibold">Chave de Acesso</h2>
              <p className="text-sm text-muted-foreground">
                Informações da sua chave
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Nome da Chave</Label>
              <Input value={accessKey?.name || "Sem nome"} disabled />
            </div>
            <div className="space-y-2">
              <Label>Tipo de Acesso</Label>
              <Input value={isAdmin ? "Administrador" : "Usuário"} disabled />
            </div>
          </div>

          <div className="p-4 rounded-lg bg-secondary/50">
            <p className="text-sm text-muted-foreground">
              Para alterar sua chave de acesso ou obter uma nova, entre em contato com um administrador.
            </p>
          </div>
        </div>

        {/* Notifications Section */}
        <div className="glass-card p-6 space-y-6 animate-fade-in" style={{ animationDelay: "0.1s" }}>
          <div className="flex items-center gap-3 pb-4 border-b border-border">
            <div className="p-2 rounded-lg bg-primary/20">
              <Bell className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h2 className="font-semibold">Notificações</h2>
              <p className="text-sm text-muted-foreground">
                Configure suas preferências de notificação
              </p>
            </div>
          </div>

          <div className="space-y-4">
            {[
              { label: "Servidor offline", description: "Receber alerta quando um servidor ficar offline" },
              { label: "Limite de recursos", description: "Alerta quando RAM ou armazenamento estiver alto" },
              { label: "Atualizações do sistema", description: "Novidades e melhorias da plataforma" },
            ].map((item, i) => (
              <div key={i} className="flex items-center justify-between py-2">
                <div>
                  <p className="font-medium">{item.label}</p>
                  <p className="text-sm text-muted-foreground">{item.description}</p>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input type="checkbox" defaultChecked className="sr-only peer" />
                  <div className="w-11 h-6 bg-secondary rounded-full peer peer-checked:bg-primary peer-focus:ring-2 peer-focus:ring-primary/20 after:content-[''] after:absolute after:top-0.5 after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:after:translate-x-full" />
                </label>
              </div>
            ))}
          </div>

          <div className="flex justify-end">
            <Button variant="glow" onClick={handleSave}>
              Salvar Alterações
            </Button>
          </div>
        </div>
      </div>
    </Layout>
  );
}
