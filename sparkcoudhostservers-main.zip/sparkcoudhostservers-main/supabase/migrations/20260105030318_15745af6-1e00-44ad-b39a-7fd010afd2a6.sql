-- Add new columns to access_keys for device limits and queue system
ALTER TABLE public.access_keys 
  ADD COLUMN IF NOT EXISTS ram_limit integer DEFAULT 2,
  ADD COLUMN IF NOT EXISTS storage_limit integer DEFAULT 50,
  ADD COLUMN IF NOT EXISTS max_devices integer DEFAULT 1,
  ADD COLUMN IF NOT EXISTS current_devices integer DEFAULT 0,
  ADD COLUMN IF NOT EXISTS is_approved boolean DEFAULT false,
  ADD COLUMN IF NOT EXISTS pending_approval boolean DEFAULT true;

-- Create site_settings table for maintenance mode, title, logo, discord link
CREATE TABLE IF NOT EXISTS public.site_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  site_title text DEFAULT 'LAC HOST',
  site_logo_url text DEFAULT NULL,
  discord_link text DEFAULT 'https://discord.gg/lachost',
  maintenance_mode boolean DEFAULT false,
  auto_approve_keys boolean DEFAULT false,
  updated_at timestamp with time zone DEFAULT now()
);

-- Enable RLS on site_settings
ALTER TABLE public.site_settings ENABLE ROW LEVEL SECURITY;

-- Policies for site_settings (only admins can manage, anyone can read)
CREATE POLICY "Anyone can read site settings"
  ON public.site_settings
  FOR SELECT
  USING (true);

CREATE POLICY "Admins can update site settings"
  ON public.site_settings
  FOR UPDATE
  USING (true);

CREATE POLICY "Admins can insert site settings"
  ON public.site_settings
  FOR INSERT
  WITH CHECK (true);

-- Insert default site settings
INSERT INTO public.site_settings (site_title, discord_link, maintenance_mode, auto_approve_keys)
VALUES ('LAC HOST', 'https://discord.gg/lachost', false, false)
ON CONFLICT DO NOTHING;

-- Add server_url column to access_keys for admin-only VPS URL management
ALTER TABLE public.access_keys
  ADD COLUMN IF NOT EXISTS server_url text DEFAULT NULL;

-- Update existing ADMIN-MASTER-2024 key to be approved
UPDATE public.access_keys 
SET is_approved = true, pending_approval = false 
WHERE key_code = 'ADMIN-MASTER-2024';

-- Add realtime for site_settings
ALTER PUBLICATION supabase_realtime ADD TABLE public.site_settings;