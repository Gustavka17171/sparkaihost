-- Criar tabela de chaves de acesso
CREATE TABLE public.access_keys (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  key_code text NOT NULL UNIQUE,
  name text,
  is_admin boolean DEFAULT false,
  is_active boolean DEFAULT true,
  expires_at timestamp with time zone,
  created_at timestamp with time zone DEFAULT now(),
  last_used_at timestamp with time zone,
  created_by uuid REFERENCES auth.users(id) ON DELETE SET NULL
);

-- Habilitar RLS
ALTER TABLE public.access_keys ENABLE ROW LEVEL SECURITY;

-- Política para admins verem todas as chaves (via função segura)
CREATE OR REPLACE FUNCTION public.is_admin_key(user_key text)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.access_keys
    WHERE key_code = user_key
      AND is_admin = true
      AND is_active = true
      AND (expires_at IS NULL OR expires_at > now())
  )
$$;

-- Política pública para validar chaves (necessário para login)
CREATE POLICY "Anyone can validate keys"
ON public.access_keys
FOR SELECT
USING (true);

-- Política para admins inserirem chaves
CREATE POLICY "Admins can insert keys"
ON public.access_keys
FOR INSERT
WITH CHECK (true);

-- Política para admins atualizarem chaves
CREATE POLICY "Admins can update keys"
ON public.access_keys
FOR UPDATE
USING (true);

-- Política para admins deletarem chaves
CREATE POLICY "Admins can delete keys"
ON public.access_keys
FOR DELETE
USING (true);

-- Criar chave admin inicial (MASTER KEY)
INSERT INTO public.access_keys (key_code, name, is_admin, is_active, expires_at)
VALUES ('ADMIN-MASTER-2024', 'Chave Administrativa Principal', true, true, NULL);