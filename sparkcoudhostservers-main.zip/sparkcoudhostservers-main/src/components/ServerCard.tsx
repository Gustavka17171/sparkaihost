import { forwardRef } from "react";
import { Power, RotateCcw, MoreVertical, Trash2, Settings, Terminal, Users } from "lucide-react";
import { Button } from "./ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "./ui/dropdown-menu";
import { cn } from "@/lib/utils";

interface ServerCardProps {
  name: string;
  status: "online" | "offline";
  ramUsed: number;
  ramTotal: number;
  storageUsed: number;
  storageTotal: number;
  playersOnline?: number;
  maxPlayers?: number;
  plan?: string;
  onStart?: () => void;
  onStop?: () => void;
  onRestart?: () => void;
  onDelete?: () => void;
  onSettings?: () => void;
  onConsole?: () => void;
  showAdminActions?: boolean;
}

export const ServerCard = forwardRef<HTMLDivElement, ServerCardProps>(
  (
    {
      name,
      status,
      ramUsed,
      ramTotal,
      storageUsed,
      storageTotal,
      playersOnline = 0,
      maxPlayers = 32,
      plan,
      onStart,
      onStop,
      onRestart,
      onDelete,
      onSettings,
      onConsole,
      showAdminActions = false,
    },
    ref
  ) => {
    const ramPercentage = (ramUsed / ramTotal) * 100;
    const storagePercentage = (storageUsed / storageTotal) * 100;

    return (
      <div ref={ref} className="glass-card glow-border p-6 space-y-5 animate-fade-in h-full">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div
              className={cn(
                "w-3 h-3 rounded-full",
                status === "online" ? "bg-success animate-pulse-glow" : "bg-destructive"
              )}
            />
            <h3 className="font-semibold text-lg truncate">{name}</h3>
          </div>
          <div className="flex items-center gap-2">
            <span
              className={cn(
                "px-3 py-1 rounded-full text-xs font-medium uppercase tracking-wide",
                status === "online"
                  ? "bg-success/20 text-success"
                  : "bg-destructive/20 text-destructive"
              )}
            >
              {status}
            </span>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="h-8 w-8">
                  <MoreVertical className="w-4 h-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-48">
                <DropdownMenuItem onClick={onConsole}>
                  <Terminal className="w-4 h-4 mr-2" />
                  Console
                </DropdownMenuItem>
                <DropdownMenuItem onClick={onSettings}>
                  <Settings className="w-4 h-4 mr-2" />
                  Configurações
                </DropdownMenuItem>
                <DropdownMenuItem onClick={onRestart}>
                  <RotateCcw className="w-4 h-4 mr-2" />
                  Reiniciar
                </DropdownMenuItem>
                {showAdminActions && (
                  <>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={onDelete} className="text-destructive focus:text-destructive">
                      <Trash2 className="w-4 h-4 mr-2" />
                      Excluir Servidor
                    </DropdownMenuItem>
                  </>
                )}
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>

        {/* Players Online */}
        {status === "online" && (
          <div className="flex items-center gap-2 px-3 py-2 rounded-lg bg-secondary/50">
            <Users className="w-4 h-4 text-primary" />
            <span className="text-sm">
              <span className="font-mono font-bold text-primary">{playersOnline}</span>
              <span className="text-muted-foreground"> / {maxPlayers} jogadores</span>
            </span>
          </div>
        )}

        {/* Controls */}
        <div className="flex gap-2">
          {status === "offline" ? (
            <Button variant="success" size="default" onClick={onStart} className="flex-1">
              <Power className="w-4 h-4" />
              Iniciar
            </Button>
          ) : (
            <Button variant="destructive" size="default" onClick={onStop} className="flex-1">
              <Power className="w-4 h-4" />
              Parar
            </Button>
          )}
        </div>

        {/* Stats */}
        <div className="space-y-4">
          {/* RAM */}
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">RAM</span>
              <span className="font-mono font-medium">
                {ramUsed.toFixed(1)} / {ramTotal} GB
              </span>
            </div>
            <div className="progress-bar">
              <div
                className="progress-fill"
                style={{ width: `${Math.min(ramPercentage, 100)}%` }}
              />
            </div>
          </div>

          {/* Storage */}
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Armazenamento</span>
              <span className="font-mono font-medium">
                {storageUsed.toFixed(1)} / {storageTotal} GB
              </span>
            </div>
            <div className="progress-bar">
              <div
                className="progress-fill"
                style={{ width: `${Math.min(storagePercentage, 100)}%` }}
              />
            </div>
          </div>
        </div>

        {/* Plan Badge */}
        {plan && (
          <div className="pt-2 border-t border-border">
            <span className="text-xs text-muted-foreground">Plano: </span>
            <span className="text-xs font-medium text-primary">{plan}</span>
          </div>
        )}
      </div>
    );
  }
);

ServerCard.displayName = "ServerCard";
