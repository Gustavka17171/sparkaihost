import { useState } from "react";
import { Folder, FileText, ChevronRight, ChevronDown, File, FolderPlus, FilePlus, Trash2, Edit } from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "./ui/dialog";
import {
  ContextMenu,
  ContextMenuContent,
  ContextMenuItem,
  ContextMenuTrigger,
} from "./ui/context-menu";

export interface FileItem {
  name: string;
  type: "folder" | "file";
  size?: string;
  children?: FileItem[];
}

interface FileManagerProps {
  files: FileItem[];
  onFileClick?: (file: FileItem) => void;
  onCreateFolder?: (path: string[], name: string) => void;
  onCreateFile?: (path: string[], name: string) => void;
  onDeleteFile?: (path: string[], name: string) => void;
}

function FileTreeItem({ 
  item, 
  depth = 0,
  path = [],
  onFileClick,
  onCreateFolder,
  onCreateFile,
  onDeleteFile
}: { 
  item: FileItem; 
  depth?: number;
  path?: string[];
  onFileClick?: (file: FileItem) => void;
  onCreateFolder?: (path: string[], name: string) => void;
  onCreateFile?: (path: string[], name: string) => void;
  onDeleteFile?: (path: string[], name: string) => void;
}) {
  const [isExpanded, setIsExpanded] = useState(false);
  const isFolder = item.type === "folder";
  const isEditable = item.name.endsWith(".txt") || item.name.endsWith(".cfg") || item.name.endsWith(".config");
  
  const handleClick = () => {
    if (isFolder) {
      setIsExpanded(!isExpanded);
    } else if (isEditable) {
      onFileClick?.(item);
    }
  };

  const currentPath = [...path, item.name];

  const handleDelete = () => {
    onDeleteFile?.(path, item.name);
  };

  return (
    <ContextMenu>
      <ContextMenuTrigger>
        <div>
          <div
            className={cn(
              "flex items-center gap-2 px-3 py-2 rounded-lg cursor-pointer transition-colors hover:bg-secondary/50",
              depth > 0 && "ml-4",
              isEditable && "hover:bg-primary/10"
            )}
            onClick={handleClick}
          >
            {isFolder && (
              <span className="w-4 h-4 flex items-center justify-center">
                {isExpanded ? (
                  <ChevronDown className="w-3 h-3 text-muted-foreground" />
                ) : (
                  <ChevronRight className="w-3 h-3 text-muted-foreground" />
                )}
              </span>
            )}
            
            {isFolder ? (
              <Folder className="w-5 h-5 text-warning" />
            ) : item.name.endsWith(".so") ? (
              <File className="w-5 h-5 text-muted-foreground" />
            ) : isEditable ? (
              <FileText className="w-5 h-5 text-primary" />
            ) : (
              <FileText className="w-5 h-5 text-muted-foreground" />
            )}
            
            <span className={cn(
              "flex-1 text-sm",
              isFolder ? "text-warning font-medium" : isEditable ? "text-primary" : "text-foreground"
            )}>
              {item.name}
            </span>

            {isEditable && (
              <Edit className="w-3 h-3 text-muted-foreground" />
            )}
            
            {item.size && (
              <span className="text-xs text-muted-foreground">{item.size}</span>
            )}
          </div>
          
          {isFolder && isExpanded && (
            <div className="border-l border-border/50 ml-5">
              {item.children && item.children.map((child, index) => (
                <FileTreeItem 
                  key={`${child.name}-${index}`} 
                  item={child} 
                  depth={depth + 1}
                  path={currentPath}
                  onFileClick={onFileClick}
                  onCreateFolder={onCreateFolder}
                  onCreateFile={onCreateFile}
                  onDeleteFile={onDeleteFile}
                />
              ))}
            </div>
          )}
        </div>
      </ContextMenuTrigger>
      <ContextMenuContent>
        {isEditable && (
          <ContextMenuItem onClick={() => onFileClick?.(item)}>
            <Edit className="w-4 h-4 mr-2" />
            Editar
          </ContextMenuItem>
        )}
        <ContextMenuItem onClick={handleDelete} className="text-destructive">
          <Trash2 className="w-4 h-4 mr-2" />
          Excluir
        </ContextMenuItem>
      </ContextMenuContent>
    </ContextMenu>
  );
}

export function FileManager({ files, onFileClick, onCreateFolder, onCreateFile, onDeleteFile }: FileManagerProps) {
  const [createDialogOpen, setCreateDialogOpen] = useState(false);
  const [createType, setCreateType] = useState<"folder" | "file">("folder");
  const [newItemName, setNewItemName] = useState("");

  const handleCreate = () => {
    if (!newItemName.trim()) return;
    
    if (createType === "folder") {
      onCreateFolder?.([], newItemName.trim());
    } else {
      onCreateFile?.([], newItemName.trim());
    }
    
    setNewItemName("");
    setCreateDialogOpen(false);
  };

  const openCreateDialog = (type: "folder" | "file") => {
    setCreateType(type);
    setNewItemName("");
    setCreateDialogOpen(true);
  };

  if (files.length === 0) {
    return (
      <div className="glass-card p-6">
        <div className="text-center mb-4">
          <Folder className="w-12 h-12 mx-auto text-muted-foreground mb-3" />
          <p className="text-muted-foreground text-sm">
            Pasta files vazia. Inicie o servidor para criar a estrutura de arquivos.
          </p>
        </div>
        <div className="flex gap-2 justify-center">
          <Button variant="outline" size="sm" onClick={() => openCreateDialog("folder")}>
            <FolderPlus className="w-4 h-4 mr-2" />
            Nova Pasta
          </Button>
          <Button variant="outline" size="sm" onClick={() => openCreateDialog("file")}>
            <FilePlus className="w-4 h-4 mr-2" />
            Novo Arquivo
          </Button>
        </div>
        
        <Dialog open={createDialogOpen} onOpenChange={setCreateDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>
                {createType === "folder" ? "Nova Pasta" : "Novo Arquivo"}
              </DialogTitle>
            </DialogHeader>
            <div className="py-4">
              <Input
                placeholder={createType === "folder" ? "Nome da pasta" : "Nome do arquivo (ex: config.txt)"}
                value={newItemName}
                onChange={(e) => setNewItemName(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleCreate()}
              />
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setCreateDialogOpen(false)}>
                Cancelar
              </Button>
              <Button onClick={handleCreate}>
                Criar
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    );
  }

  return (
    <div className="glass-card p-4 space-y-1">
      <div className="flex items-center justify-between px-3 py-2 border-b border-border mb-2">
        <div className="flex items-center gap-2">
          <Folder className="w-5 h-5 text-primary" />
          <span className="font-medium">files</span>
        </div>
        <div className="flex gap-1">
          <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => openCreateDialog("folder")} title="Nova Pasta">
            <FolderPlus className="w-4 h-4" />
          </Button>
          <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => openCreateDialog("file")} title="Novo Arquivo">
            <FilePlus className="w-4 h-4" />
          </Button>
        </div>
      </div>

      <div className="text-xs text-muted-foreground px-3 py-1 mb-2">
        Clique com botão direito para opções. Arquivos .txt e .cfg são editáveis.
      </div>

      {files.map((item, index) => (
        <FileTreeItem 
          key={`${item.name}-${index}`} 
          item={item}
          path={[]}
          onFileClick={onFileClick}
          onCreateFolder={onCreateFolder}
          onCreateFile={onCreateFile}
          onDeleteFile={onDeleteFile}
        />
      ))}
      
      <Dialog open={createDialogOpen} onOpenChange={setCreateDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {createType === "folder" ? "Nova Pasta" : "Novo Arquivo"}
            </DialogTitle>
          </DialogHeader>
          <div className="py-4">
            <Input
              placeholder={createType === "folder" ? "Nome da pasta" : "Nome do arquivo (ex: config.txt)"}
              value={newItemName}
              onChange={(e) => setNewItemName(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleCreate()}
            />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setCreateDialogOpen(false)}>
              Cancelar
            </Button>
            <Button onClick={handleCreate}>
              Criar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

// Default LAC server file structure with proper nested folders
export const DEFAULT_SERVER_FILES: FileItem[] = [
  {
    name: ".config",
    type: "folder",
    children: [
      {
        name: "unity3d",
        type: "folder",
        children: [
          {
            name: "MA",
            type: "folder",
            children: [
              {
                name: "LAC",
                type: "folder",
                children: [
                  {
                    name: "Unity",
                    type: "folder",
                    children: []
                  },
                  {
                    name: "prefs",
                    type: "file",
                    size: "317 B"
                  },
                  {
                    name: "ServerConfig.txt",
                    type: "file",
                    size: "713 B"
                  }
                ]
              }
            ]
          }
        ]
      }
    ]
  },
  {
    name: "LAC_Linux_v1.9.2_Data",
    type: "folder",
    children: []
  },
  {
    name: "GameAssembly.so",
    type: "file",
    size: "47MB"
  },
  {
    name: "LAC_Linux_v1.9.2.x86_64",
    type: "file",
    size: "14MB"
  },
  {
    name: "UnityPlayer.so",
    type: "file",
    size: "29MB"
  }
];
