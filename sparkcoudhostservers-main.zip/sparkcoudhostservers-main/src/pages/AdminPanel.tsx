import { useState, useEffect } from "react";
import { 
  Server, Shield, Key, Plus, Trash2, Copy, Eye, EyeOff, FolderOpen, 
  RefreshCw, HardDrive, Cpu, Check, X, Settings2, Link2, Paintbrush,
  AlertTriangle, Users, Clock
} from "lucide-react";
import { Layout } from "@/components/Layout";
import { StatCard } from "@/components/StatCard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Navigate } from "react-router-dom";

interface AccessKeyData {
  id: string;
  key_code: string;
  name: string | null;
  is_admin: boolean;
  is_active: boolean;
  expires_at: string | null;
  created_at: string;
  last_used_at: string | null;
  ram_limit: number;
  storage_limit: number;
  max_devices: number;
  current_devices: number;
  is_approved: boolean;
  pending_approval: boolean;
  server_url: string | null;
}

interface ServerData {
  id: string;
  name: string;
  status: string;
  user_id: string;
  server_url: string | null;
}

interface SiteSettings {
  id: string;
  site_title: string;
  site_logo_url: string | null;
  discord_link: string;
  maintenance_mode: boolean;
  auto_approve_keys: boolean;
}

export default function AdminPanel() {
  const { isAdmin, accessKey, refreshSiteSettings } = useAuth();
  const [keys, setKeys] = useState<AccessKeyData[]>([]);
  const [servers, setServers] = useState<ServerData[]>([]);
  const [loading, setLoading] = useState(true);
  const [createDialogOpen, setCreateDialogOpen] = useState(false);
  const [showKeys, setShowKeys] = useState<Record<string, boolean>>({});
  const [siteSettings, setSiteSettings] = useState<SiteSettings | null>(null);
  const [settingsLoading, setSettingsLoading] = useState(false);
  
  // New key form state
  const [newKeyName, setNewKeyName] = useState("");
  const [newKeyIsAdmin, setNewKeyIsAdmin] = useState(false);
  const [newKeyExpires, setNewKeyExpires] = useState("");
  const [newKeyRamLimit, setNewKeyRamLimit] = useState("2");
  const [newKeyStorageLimit, setNewKeyStorageLimit] = useState("50");
  const [newKeyMaxDevices, setNewKeyMaxDevices] = useState("1");

  // Site settings form
  const [editSiteTitle, setEditSiteTitle] = useState("");
  const [editSiteLogo, setEditSiteLogo] = useState("");
  const [editDiscordLink, setEditDiscordLink] = useState("");

  // Edit key dialog
  const [editKeyDialogOpen, setEditKeyDialogOpen] = useState(false);
  const [editingKey, setEditingKey] = useState<AccessKeyData | null>(null);
  const [editKeyServerUrl, setEditKeyServerUrl] = useState("");
  const [editKeyRamLimit, setEditKeyRamLimit] = useState("");
  const [editKeyStorageLimit, setEditKeyStorageLimit] = useState("");
  const [editKeyMaxDevices, setEditKeyMaxDevices] = useState("");

  if (!isAdmin) {
    return <Navigate to="/" replace />;
  }

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    setLoading(true);
    
    // Fetch access keys
    const { data: keysData, error: keysError } = await supabase
      .from("access_keys")
      .select("*")
      .order("created_at", { ascending: false });

    if (keysError) {
      toast.error("Erro ao carregar chaves");
    } else {
      setKeys(keysData as AccessKeyData[]);
    }

    // Fetch all servers
    const { data: serversData, error: serversError } = await supabase
      .from("servers")
      .select("*")
      .order("created_at", { ascending: false });

    if (serversError) {
      toast.error("Erro ao carregar servidores");
    } else {
      setServers(serversData as ServerData[]);
    }

    // Fetch site settings
    const { data: settingsData } = await supabase
      .from("site_settings")
      .select("*")
      .limit(1)
      .maybeSingle();

    if (settingsData) {
      setSiteSettings(settingsData as SiteSettings);
      setEditSiteTitle(settingsData.site_title || "LAC HOST");
      setEditSiteLogo(settingsData.site_logo_url || "");
      setEditDiscordLink(settingsData.discord_link || "");
    }

    setLoading(false);
  };

  const generateKeyCode = () => {
    const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    const segments = [];
    for (let s = 0; s < 4; s++) {
      let segment = "";
      for (let i = 0; i < 4; i++) {
        segment += chars.charAt(Math.floor(Math.random() * chars.length));
      }
      segments.push(segment);
    }
    return segments.join("-");
  };

  const handleCreateKey = async () => {
    const keyCode = generateKeyCode();
    const autoApprove = siteSettings?.auto_approve_keys || false;
    
    const { error } = await supabase.from("access_keys").insert({
      key_code: keyCode,
      name: newKeyName || null,
      is_admin: newKeyIsAdmin,
      expires_at: newKeyExpires ? new Date(newKeyExpires).toISOString() : null,
      ram_limit: parseInt(newKeyRamLimit) || 2,
      storage_limit: parseInt(newKeyStorageLimit) || 50,
      max_devices: parseInt(newKeyMaxDevices) || 1,
      is_approved: autoApprove,
      pending_approval: !autoApprove,
    });

    if (error) {
      toast.error("Erro ao criar chave");
    } else {
      toast.success(`Chave criada: ${keyCode}`);
      setCreateDialogOpen(false);
      resetNewKeyForm();
      fetchData();
    }
  };

  const resetNewKeyForm = () => {
    setNewKeyName("");
    setNewKeyIsAdmin(false);
    setNewKeyExpires("");
    setNewKeyRamLimit("2");
    setNewKeyStorageLimit("50");
    setNewKeyMaxDevices("1");
  };

  const handleApproveKey = async (key: AccessKeyData) => {
    const { error } = await supabase
      .from("access_keys")
      .update({ is_approved: true, pending_approval: false })
      .eq("id", key.id);

    if (error) {
      toast.error("Erro ao aprovar chave");
    } else {
      toast.success("Chave aprovada!");
      fetchData();
    }
  };

  const handleRejectKey = async (key: AccessKeyData) => {
    const { error } = await supabase
      .from("access_keys")
      .update({ is_approved: false, pending_approval: false, is_active: false })
      .eq("id", key.id);

    if (error) {
      toast.error("Erro ao rejeitar chave");
    } else {
      toast.success("Chave rejeitada");
      fetchData();
    }
  };

  const handleToggleActive = async (key: AccessKeyData) => {
    if (key.key_code === accessKey?.key_code) {
      toast.error("Você não pode desativar sua própria chave");
      return;
    }

    const { error } = await supabase
      .from("access_keys")
      .update({ is_active: !key.is_active })
      .eq("id", key.id);

    if (error) {
      toast.error("Erro ao atualizar chave");
    } else {
      toast.success(key.is_active ? "Chave desativada" : "Chave ativada");
      fetchData();
    }
  };

  const handleDeleteKey = async (key: AccessKeyData) => {
    if (key.key_code === accessKey?.key_code) {
      toast.error("Você não pode excluir sua própria chave");
      return;
    }

    const { error } = await supabase.from("access_keys").delete().eq("id", key.id);

    if (error) {
      toast.error("Erro ao excluir chave");
    } else {
      toast.success("Chave excluída");
      fetchData();
    }
  };

  const handleEditKey = (key: AccessKeyData) => {
    setEditingKey(key);
    setEditKeyServerUrl(key.server_url || "");
    setEditKeyRamLimit(String(key.ram_limit || 2));
    setEditKeyStorageLimit(String(key.storage_limit || 50));
    setEditKeyMaxDevices(String(key.max_devices || 1));
    setEditKeyDialogOpen(true);
  };

  const handleSaveKeySettings = async () => {
    if (!editingKey) return;

    const { error } = await supabase
      .from("access_keys")
      .update({
        server_url: editKeyServerUrl.trim() || null,
        ram_limit: parseInt(editKeyRamLimit) || 2,
        storage_limit: parseInt(editKeyStorageLimit) || 50,
        max_devices: parseInt(editKeyMaxDevices) || 1,
      })
      .eq("id", editingKey.id);

    if (error) {
      toast.error("Erro ao salvar configurações");
    } else {
      toast.success("Configurações salvas!");
      setEditKeyDialogOpen(false);
      fetchData();
    }
  };

  const handleToggleMaintenance = async () => {
    if (!siteSettings) return;
    setSettingsLoading(true);

    const { error } = await supabase
      .from("site_settings")
      .update({ maintenance_mode: !siteSettings.maintenance_mode })
      .eq("id", siteSettings.id);

    if (error) {
      toast.error("Erro ao atualizar modo manutenção");
    } else {
      toast.success(siteSettings.maintenance_mode ? "Manutenção desativada" : "Manutenção ativada");
      fetchData();
      refreshSiteSettings();
    }
    setSettingsLoading(false);
  };

  const handleToggleAutoApprove = async () => {
    if (!siteSettings) return;
    setSettingsLoading(true);

    const { error } = await supabase
      .from("site_settings")
      .update({ auto_approve_keys: !siteSettings.auto_approve_keys })
      .eq("id", siteSettings.id);

    if (error) {
      toast.error("Erro ao atualizar auto-aprovação");
    } else {
      toast.success(siteSettings.auto_approve_keys ? "Auto-aprovação desativada" : "Auto-aprovação ativada");
      fetchData();
    }
    setSettingsLoading(false);
  };

  const handleSaveSiteSettings = async () => {
    if (!siteSettings) return;
    setSettingsLoading(true);

    const { error } = await supabase
      .from("site_settings")
      .update({
        site_title: editSiteTitle.trim() || "LAC HOST",
        site_logo_url: editSiteLogo.trim() || null,
        discord_link: editDiscordLink.trim() || "https://discord.gg/lachost",
      })
      .eq("id", siteSettings.id);

    if (error) {
      toast.error("Erro ao salvar configurações");
    } else {
      toast.success("Configurações do site salvas!");
      fetchData();
      refreshSiteSettings();
    }
    setSettingsLoading(false);
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast.success("Copiado!");
  };

  const toggleShowKey = (id: string) => {
    setShowKeys((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  const formatDate = (dateString: string | null) => {
    if (!dateString) return "-";
    return new Date(dateString).toLocaleDateString("pt-BR", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  const activeKeys = keys.filter((k) => k.is_active).length;
  const pendingKeys = keys.filter((k) => k.pending_approval && !k.is_approved).length;
  const onlineServers = servers.filter((s) => s.status === "online").length;

  return (
    <Layout>
      <div className="space-y-6">
        {/* Header */}
        <div className="animate-slide-up">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-primary/20">
                <Shield className="w-6 h-6 text-primary" />
              </div>
              <div>
                <h1 className="text-2xl lg:text-3xl font-bold">Painel Administrativo</h1>
                <p className="text-muted-foreground">
                  Gerencie chaves, servidores e configurações
                </p>
              </div>
            </div>
            <Button variant="ghost" size="icon" onClick={fetchData}>
              <RefreshCw className="w-4 h-4" />
            </Button>
          </div>
        </div>

        {/* Maintenance Alert */}
        {siteSettings?.maintenance_mode && (
          <div className="p-4 rounded-lg bg-warning/20 border border-warning/30 flex items-center gap-3 animate-fade-in">
            <AlertTriangle className="w-5 h-5 text-warning" />
            <div>
              <p className="font-medium text-warning">Modo Manutenção Ativo</p>
              <p className="text-sm text-muted-foreground">
                Apenas administradores podem acessar o sistema
              </p>
            </div>
            <Button 
              variant="outline" 
              size="sm" 
              className="ml-auto"
              onClick={handleToggleMaintenance}
            >
              Desativar
            </Button>
          </div>
        )}

        {/* Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard
            title="Total de Chaves"
            value={keys.length}
            subtitle={`${activeKeys} ativas`}
            icon={Key}
            variant="default"
          />
          <StatCard
            title="Fila de Aprovação"
            value={pendingKeys}
            subtitle="aguardando"
            icon={Clock}
            variant="warning"
          />
          <StatCard
            title="Servidores"
            value={servers.length}
            subtitle={`${onlineServers} online`}
            icon={Server}
            variant="success"
          />
          <StatCard
            title="Usuários"
            value={keys.filter(k => !k.is_admin).length}
            subtitle="não-admin"
            icon={Users}
            variant="default"
          />
        </div>

        {/* Tabs */}
        <Tabs defaultValue="keys" className="space-y-4">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="keys">Chaves</TabsTrigger>
            <TabsTrigger value="queue">Fila ({pendingKeys})</TabsTrigger>
            <TabsTrigger value="servers">Servidores</TabsTrigger>
            <TabsTrigger value="settings">Configurações</TabsTrigger>
          </TabsList>

          {/* Keys Tab */}
          <TabsContent value="keys" className="space-y-4">
            <div className="glass-card p-6 animate-fade-in">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-semibold">Chaves de Acesso</h2>
                <Dialog open={createDialogOpen} onOpenChange={setCreateDialogOpen}>
                  <DialogTrigger asChild>
                    <Button variant="glow" size="sm">
                      <Plus className="w-4 h-4 mr-2" />
                      Nova Chave
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-md">
                    <DialogHeader>
                      <DialogTitle>Criar Nova Chave</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4 mt-4">
                      <div className="space-y-2">
                        <Label>Nome (opcional)</Label>
                        <Input
                          placeholder="Ex: Cliente VIP"
                          value={newKeyName}
                          onChange={(e) => setNewKeyName(e.target.value)}
                        />
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label>Limite RAM (GB)</Label>
                          <Input
                            type="number"
                            value={newKeyRamLimit}
                            onChange={(e) => setNewKeyRamLimit(e.target.value)}
                            min="1"
                            max="32"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label>Limite Storage (GB)</Label>
                          <Input
                            type="number"
                            value={newKeyStorageLimit}
                            onChange={(e) => setNewKeyStorageLimit(e.target.value)}
                            min="1"
                            max="500"
                          />
                        </div>
                      </div>
                      <div className="space-y-2">
                        <Label>Máx. Dispositivos</Label>
                        <Input
                          type="number"
                          value={newKeyMaxDevices}
                          onChange={(e) => setNewKeyMaxDevices(e.target.value)}
                          min="1"
                          max="10"
                        />
                        <p className="text-xs text-muted-foreground">
                          Quantos dispositivos podem acessar simultaneamente
                        </p>
                      </div>
                      <div className="space-y-2">
                        <Label>Data de Expiração (opcional)</Label>
                        <Input
                          type="datetime-local"
                          value={newKeyExpires}
                          onChange={(e) => setNewKeyExpires(e.target.value)}
                        />
                      </div>
                      <div className="flex items-center justify-between">
                        <Label>Acesso Administrativo</Label>
                        <Switch
                          checked={newKeyIsAdmin}
                          onCheckedChange={setNewKeyIsAdmin}
                        />
                      </div>
                      <Button onClick={handleCreateKey} className="w-full" variant="glow">
                        Gerar Chave
                      </Button>
                    </div>
                  </DialogContent>
                </Dialog>
              </div>

              {loading ? (
                <div className="py-12 text-center">
                  <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin mx-auto" />
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Nome</TableHead>
                        <TableHead>Chave</TableHead>
                        <TableHead>RAM/Storage</TableHead>
                        <TableHead>Tipo</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead className="text-right">Ações</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {keys.filter(k => k.is_approved || !k.pending_approval).map((key) => (
                        <TableRow key={key.id}>
                          <TableCell className="font-medium">
                            {key.name || "-"}
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <code className="text-xs bg-secondary px-2 py-1 rounded font-mono">
                                {showKeys[key.id] ? key.key_code : "••••-••••-••••-••••"}
                              </code>
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-6 w-6"
                                onClick={() => toggleShowKey(key.id)}
                              >
                                {showKeys[key.id] ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                              </Button>
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-6 w-6"
                                onClick={() => copyToClipboard(key.key_code)}
                              >
                                <Copy className="w-3 h-3" />
                              </Button>
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="text-xs">
                              <span className="text-primary">{key.ram_limit}GB</span>
                              <span className="text-muted-foreground"> / </span>
                              <span className="text-primary">{key.storage_limit}GB</span>
                            </div>
                          </TableCell>
                          <TableCell>
                            <span className={`px-2 py-1 rounded-md text-xs font-medium ${
                              key.is_admin
                                ? "bg-warning/20 text-warning"
                                : "bg-secondary text-muted-foreground"
                            }`}>
                              {key.is_admin ? "Admin" : "Usuário"}
                            </span>
                          </TableCell>
                          <TableCell>
                            <span className={`px-2 py-1 rounded-md text-xs font-medium ${
                              key.is_active
                                ? "bg-success/20 text-success"
                                : "bg-destructive/20 text-destructive"
                            }`}>
                              {key.is_active ? "Ativa" : "Inativa"}
                            </span>
                          </TableCell>
                          <TableCell>
                            <div className="flex justify-end gap-1">
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-8 w-8"
                                onClick={() => handleEditKey(key)}
                                title="Configurações"
                              >
                                <Settings2 className="w-4 h-4" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-8 w-8"
                                onClick={() => handleToggleActive(key)}
                                disabled={key.key_code === accessKey?.key_code}
                              >
                                <Switch
                                  checked={key.is_active}
                                  className="pointer-events-none scale-75"
                                />
                              </Button>
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-8 w-8 text-destructive hover:text-destructive"
                                onClick={() => handleDeleteKey(key)}
                                disabled={key.key_code === accessKey?.key_code}
                              >
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </div>
          </TabsContent>

          {/* Queue Tab */}
          <TabsContent value="queue" className="space-y-4">
            <div className="glass-card p-6 animate-fade-in">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-semibold">Fila de Aprovação</h2>
                <div className="flex items-center gap-2">
                  <span className="text-sm text-muted-foreground">Auto-aprovar:</span>
                  <Switch
                    checked={siteSettings?.auto_approve_keys || false}
                    onCheckedChange={handleToggleAutoApprove}
                    disabled={settingsLoading}
                  />
                </div>
              </div>

              {keys.filter(k => k.pending_approval && !k.is_approved).length === 0 ? (
                <div className="py-12 text-center">
                  <Clock className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
                  <h3 className="font-semibold text-lg">Nenhuma chave pendente</h3>
                  <p className="text-muted-foreground text-sm">
                    Novas chaves pendentes aparecerão aqui
                  </p>
                </div>
              ) : (
                <div className="space-y-3">
                  {keys.filter(k => k.pending_approval && !k.is_approved).map((key) => (
                    <div key={key.id} className="flex items-center justify-between p-4 rounded-lg bg-secondary/30">
                      <div>
                        <p className="font-medium">{key.name || "Sem nome"}</p>
                        <p className="text-sm text-muted-foreground font-mono">
                          {key.key_code}
                        </p>
                        <p className="text-xs text-muted-foreground mt-1">
                          RAM: {key.ram_limit}GB | Storage: {key.storage_limit}GB | Dispositivos: {key.max_devices}
                        </p>
                      </div>
                      <div className="flex gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          className="text-success hover:text-success"
                          onClick={() => handleApproveKey(key)}
                        >
                          <Check className="w-4 h-4 mr-1" />
                          Aprovar
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          className="text-destructive hover:text-destructive"
                          onClick={() => handleRejectKey(key)}
                        >
                          <X className="w-4 h-4 mr-1" />
                          Rejeitar
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </TabsContent>

          {/* Servers Tab */}
          <TabsContent value="servers" className="space-y-4">
            <div className="glass-card p-6 animate-fade-in">
              <h2 className="text-xl font-semibold mb-6">Todos os Servidores</h2>

              {servers.length === 0 ? (
                <div className="py-12 text-center">
                  <Server className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
                  <h3 className="font-semibold text-lg">Nenhum servidor encontrado</h3>
                  <p className="text-muted-foreground text-sm">
                    Os servidores criados pelos usuários aparecerão aqui
                  </p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Nome</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>URL VPS</TableHead>
                        <TableHead>ID do Usuário</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {servers.map((server) => (
                        <TableRow key={server.id}>
                          <TableCell className="font-medium">{server.name}</TableCell>
                          <TableCell>
                            <span className={`px-2 py-1 rounded-md text-xs font-medium ${
                              server.status === "online"
                                ? "bg-success/20 text-success"
                                : "bg-muted text-muted-foreground"
                            }`}>
                              {server.status === "online" ? "Online" : "Offline"}
                            </span>
                          </TableCell>
                          <TableCell className="text-sm text-muted-foreground">
                            {server.server_url || "-"}
                          </TableCell>
                          <TableCell className="font-mono text-xs text-muted-foreground">
                            {server.user_id}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </div>
          </TabsContent>

          {/* Settings Tab */}
          <TabsContent value="settings" className="space-y-4">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              {/* Site Customization */}
              <div className="glass-card p-6 animate-fade-in">
                <div className="flex items-center gap-3 mb-6">
                  <div className="p-2 rounded-lg bg-primary/20">
                    <Paintbrush className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-semibold">Personalização do Site</h3>
                    <p className="text-sm text-muted-foreground">Título, logo e links</p>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label>Título do Site</Label>
                    <Input
                      value={editSiteTitle}
                      onChange={(e) => setEditSiteTitle(e.target.value)}
                      placeholder="LAC HOST"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>URL da Logo (HTTPS)</Label>
                    <Input
                      value={editSiteLogo}
                      onChange={(e) => setEditSiteLogo(e.target.value)}
                      placeholder="https://exemplo.com/logo.png"
                    />
                    <p className="text-xs text-muted-foreground">
                      Deixe vazio para usar o ícone padrão
                    </p>
                  </div>
                  <div className="space-y-2">
                    <Label>Link do Discord</Label>
                    <Input
                      value={editDiscordLink}
                      onChange={(e) => setEditDiscordLink(e.target.value)}
                      placeholder="https://discord.gg/lachost"
                    />
                  </div>
                  <Button 
                    variant="glow" 
                    className="w-full"
                    onClick={handleSaveSiteSettings}
                    disabled={settingsLoading}
                  >
                    Salvar Personalização
                  </Button>
                </div>
              </div>

              {/* System Settings */}
              <div className="glass-card p-6 animate-fade-in">
                <div className="flex items-center gap-3 mb-6">
                  <div className="p-2 rounded-lg bg-warning/20">
                    <AlertTriangle className="w-5 h-5 text-warning" />
                  </div>
                  <div>
                    <h3 className="font-semibold">Configurações do Sistema</h3>
                    <p className="text-sm text-muted-foreground">Manutenção e aprovações</p>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 rounded-lg bg-secondary/30">
                    <div>
                      <p className="font-medium">Modo Manutenção</p>
                      <p className="text-sm text-muted-foreground">
                        Bloqueia acesso de usuários não-admin
                      </p>
                    </div>
                    <Switch
                      checked={siteSettings?.maintenance_mode || false}
                      onCheckedChange={handleToggleMaintenance}
                      disabled={settingsLoading}
                    />
                  </div>

                  <div className="flex items-center justify-between p-4 rounded-lg bg-secondary/30">
                    <div>
                      <p className="font-medium">Auto-aprovar Chaves</p>
                      <p className="text-sm text-muted-foreground">
                        Aprova novas chaves automaticamente
                      </p>
                    </div>
                    <Switch
                      checked={siteSettings?.auto_approve_keys || false}
                      onCheckedChange={handleToggleAutoApprove}
                      disabled={settingsLoading}
                    />
                  </div>

                  <div className="p-4 rounded-lg bg-primary/10 border border-primary/20">
                    <h4 className="font-medium text-primary mb-2">Como funciona a VPS?</h4>
                    <p className="text-sm text-muted-foreground">
                      Ao definir a URL da VPS nas configurações da chave (ex: http://IP:3000), 
                      o sistema irá criar automaticamente a estrutura de arquivos quando o servidor for iniciado:
                    </p>
                    <ul className="text-sm text-muted-foreground mt-2 space-y-1 list-disc list-inside">
                      <li>.config/unity3d/MA/LAC - Pasta para mapas e configurações</li>
                      <li>GameAssembly.so, UnityPlayer.so - Arquivos do jogo</li>
                      <li>LAC_Linux_v1.9.2.x86_64 - Executável do servidor</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>

      {/* Edit Key Dialog */}
      <Dialog open={editKeyDialogOpen} onOpenChange={setEditKeyDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Configurações da Chave</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 mt-4">
            <div className="space-y-2">
              <Label>URL da VPS</Label>
              <Input
                value={editKeyServerUrl}
                onChange={(e) => setEditKeyServerUrl(e.target.value)}
                placeholder="http://IP_DA_VPS:3000"
              />
              <p className="text-xs text-muted-foreground">
                Endpoints: GET /status, POST /start, POST /stop, GET /logs
              </p>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Limite RAM (GB)</Label>
                <Input
                  type="number"
                  value={editKeyRamLimit}
                  onChange={(e) => setEditKeyRamLimit(e.target.value)}
                  min="1"
                  max="32"
                />
              </div>
              <div className="space-y-2">
                <Label>Limite Storage (GB)</Label>
                <Input
                  type="number"
                  value={editKeyStorageLimit}
                  onChange={(e) => setEditKeyStorageLimit(e.target.value)}
                  min="1"
                  max="500"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label>Máx. Dispositivos</Label>
              <Input
                type="number"
                value={editKeyMaxDevices}
                onChange={(e) => setEditKeyMaxDevices(e.target.value)}
                min="1"
                max="10"
              />
            </div>
            <Button onClick={handleSaveKeySettings} className="w-full" variant="glow">
              Salvar Configurações
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </Layout>
  );
}
