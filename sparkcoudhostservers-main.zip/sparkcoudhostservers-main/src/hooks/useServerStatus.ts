import { useState, useEffect, useCallback } from "react";

interface ServerStatusResponse {
  ramUsed: number;
  ramTotal: number;
  diskUsed: number;
  diskTotal: number;
}

interface ServerStatus {
  isOnline: boolean;
  ramUsedGB: number;
  ramTotalGB: number;
  storageUsedGB: number;
  storageTotalGB: number;
  loading: boolean;
  error: string | null;
}

interface UseServerStatusOptions {
  serverUrl: string | null;
  refreshInterval?: number;
  authToken?: string;
}

export function useServerStatus({
  serverUrl,
  refreshInterval = 30000,
  authToken,
}: UseServerStatusOptions): ServerStatus & {
  refetch: () => Promise<void>;
  start: () => Promise<boolean>;
  stop: () => Promise<boolean>;
} {
  const [status, setStatus] = useState<ServerStatus>({
    isOnline: false,
    ramUsedGB: 0,
    ramTotalGB: 0,
    storageUsedGB: 0,
    storageTotalGB: 0,
    loading: true,
    error: null,
  });

  const getHeaders = useCallback(() => {
    const headers: HeadersInit = {
      "Content-Type": "application/json",
    };
    if (authToken) {
      headers["Authorization"] = `Bearer ${authToken}`;
    }
    return headers;
  }, [authToken]);

  const fetchStatus = useCallback(async () => {
    if (!serverUrl) {
      setStatus((prev) => ({
        ...prev,
        isOnline: false,
        loading: false,
        error: "URL do servidor não configurada",
      }));
      return;
    }

    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 10000);

      const response = await fetch(`${serverUrl}/status`, {
        method: "GET",
        headers: getHeaders(),
        signal: controller.signal,
      });

      clearTimeout(timeoutId);

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
      }

      const data: ServerStatusResponse = await response.json();

      setStatus({
        isOnline: true,
        ramUsedGB: Number((data.ramUsed / 1024).toFixed(2)),
        ramTotalGB: Number((data.ramTotal / 1024).toFixed(2)),
        storageUsedGB: data.diskUsed,
        storageTotalGB: data.diskTotal,
        loading: false,
        error: null,
      });
    } catch (error) {
      setStatus((prev) => ({
        ...prev,
        isOnline: false,
        loading: false,
        error: error instanceof Error ? error.message : "Erro de conexão",
      }));
    }
  }, [serverUrl, getHeaders]);

  const start = useCallback(async (): Promise<boolean> => {
    if (!serverUrl) return false;

    try {
      const response = await fetch(`${serverUrl}/start`, {
        method: "POST",
        headers: getHeaders(),
      });

      if (response.ok) {
        await fetchStatus();
        return true;
      }
      return false;
    } catch {
      return false;
    }
  }, [serverUrl, getHeaders, fetchStatus]);

  const stop = useCallback(async (): Promise<boolean> => {
    if (!serverUrl) return false;

    try {
      const response = await fetch(`${serverUrl}/stop`, {
        method: "POST",
        headers: getHeaders(),
      });

      if (response.ok) {
        await fetchStatus();
        return true;
      }
      return false;
    } catch {
      return false;
    }
  }, [serverUrl, getHeaders, fetchStatus]);

  useEffect(() => {
    fetchStatus();

    if (refreshInterval > 0 && serverUrl) {
      const interval = setInterval(fetchStatus, refreshInterval);
      return () => clearInterval(interval);
    }
  }, [fetchStatus, refreshInterval, serverUrl]);

  return {
    ...status,
    refetch: fetchStatus,
    start,
    stop,
  };
}
