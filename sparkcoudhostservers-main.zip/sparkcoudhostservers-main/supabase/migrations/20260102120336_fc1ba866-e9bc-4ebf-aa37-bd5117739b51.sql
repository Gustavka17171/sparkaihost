-- Add server_url column to servers table for external VPS API endpoint
ALTER TABLE public.servers ADD COLUMN server_url TEXT;

-- Add comment for documentation
COMMENT ON COLUMN public.servers.server_url IS 'URL da API externa do servidor VPS (ex: http://IP:3000)';