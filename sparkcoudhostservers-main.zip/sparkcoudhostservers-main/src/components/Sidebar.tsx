import { Link, useLocation, useNavigate } from "react-router-dom";
import {
  Server,
  LayoutDashboard,
  Settings,
  Shield,
  LogOut,
  Menu,
  X,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "./ui/button";
import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";

export function Sidebar() {
  const location = useLocation();
  const navigate = useNavigate();
  const { accessKey, isAdmin, signOut, siteSettings } = useAuth();
  const [collapsed, setCollapsed] = useState(false);
  const [siteTitle, setSiteTitle] = useState("LAC Host");
  const [siteLogo, setSiteLogo] = useState<string | null>(null);

  useEffect(() => {
    if (siteSettings) {
      setSiteTitle(siteSettings.site_title || "LAC Host");
      setSiteLogo(siteSettings.site_logo_url);
    }
  }, [siteSettings]);

  const userLinks = [
    { href: "/", label: "Dashboard", icon: LayoutDashboard },
    { href: "/servers", label: "Meus Servidores", icon: Server },
    { href: "/settings", label: "Configurações", icon: Settings },
  ];

  const adminLinks = [
    { href: "/admin", label: "Painel Admin", icon: Shield },
  ];

  const links = isAdmin ? [...userLinks, ...adminLinks] : userLinks;

  const handleSignOut = () => {
    signOut();
    navigate("/auth");
  };

  return (
    <aside
      className={cn(
        "fixed left-0 top-0 h-screen bg-sidebar border-r border-sidebar-border flex flex-col transition-all duration-300 z-40",
        collapsed ? "w-16" : "w-64"
      )}
    >
      {/* Logo */}
      <div className="p-4 border-b border-sidebar-border flex items-center justify-between">
        {!collapsed && (
          <div className="flex items-center gap-3">
            {siteLogo ? (
              <img 
                src={siteLogo} 
                alt={siteTitle}
                className="w-10 h-10 rounded-lg object-cover"
              />
            ) : (
              <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-primary to-accent flex items-center justify-center">
                <Server className="w-5 h-5 text-primary-foreground" />
              </div>
            )}
            <div>
              <h1 className="font-bold text-lg">{siteTitle}</h1>
              <p className="text-xs text-muted-foreground">Game Server</p>
            </div>
          </div>
        )}
        <Button
          variant="ghost"
          size="icon"
          onClick={() => setCollapsed(!collapsed)}
          className={cn("h-8 w-8", collapsed && "mx-auto")}
        >
          {collapsed ? <Menu className="w-4 h-4" /> : <X className="w-4 h-4" />}
        </Button>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-2 space-y-1 overflow-y-auto">
        {links.map((link) => {
          const isActive = location.pathname === link.href;
          return (
            <Link
              key={link.href}
              to={link.href}
              title={link.label}
              className={cn(
                "flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all duration-200",
                collapsed && "justify-center px-2",
                isActive
                  ? "bg-sidebar-accent text-sidebar-primary"
                  : "text-sidebar-foreground/70 hover:bg-sidebar-accent/50 hover:text-sidebar-foreground"
              )}
            >
              <link.icon className="w-5 h-5 shrink-0" />
              {!collapsed && link.label}
              {isActive && !collapsed && (
                <div className="ml-auto w-1.5 h-1.5 rounded-full bg-sidebar-primary" />
              )}
            </Link>
          );
        })}
      </nav>

      {/* User Section */}
      <div className="p-2 border-t border-sidebar-border">
        <div
          className={cn(
            "flex items-center gap-3 px-3 py-2.5 rounded-lg bg-sidebar-accent/30",
            collapsed && "justify-center px-2"
          )}
        >
          <div className="w-9 h-9 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center text-sm font-bold text-primary-foreground shrink-0">
            {accessKey?.name?.[0]?.toUpperCase() || "U"}
          </div>
          {!collapsed && (
            <>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium truncate">
                  {accessKey?.name || "Usuário"}
                </p>
                <p className="text-xs text-muted-foreground">
                  {isAdmin ? "Admin" : "Usuário"}
                </p>
              </div>
              <Button
                variant="ghost"
                size="icon"
                onClick={handleSignOut}
                className="h-8 w-8 shrink-0"
                title="Sair"
              >
                <LogOut className="w-4 h-4 text-muted-foreground" />
              </Button>
            </>
          )}
        </div>
      </div>
    </aside>
  );
}
