import { createContext, useContext, useState, ReactNode, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";

interface AccessKey {
  id: string;
  key_code: string;
  name: string | null;
  is_admin: boolean;
  is_active: boolean;
  expires_at: string | null;
  created_at: string;
  last_used_at: string | null;
  ram_limit: number;
  storage_limit: number;
  max_devices: number;
  current_devices: number;
  is_approved: boolean;
  pending_approval: boolean;
  server_url: string | null;
}

interface SiteSettings {
  id: string;
  site_title: string;
  site_logo_url: string | null;
  discord_link: string;
  maintenance_mode: boolean;
  auto_approve_keys: boolean;
}

interface AuthContextType {
  accessKey: AccessKey | null;
  loading: boolean;
  isAdmin: boolean;
  siteSettings: SiteSettings | null;
  validateKey: (keyCode: string) => Promise<{ error: string | null }>;
  signOut: () => void;
  refreshSiteSettings: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const STORAGE_KEY = "lac_access_key";

export function AuthProvider({ children }: { children: ReactNode }) {
  const [accessKey, setAccessKey] = useState<AccessKey | null>(null);
  const [loading, setLoading] = useState(true);
  const [siteSettings, setSiteSettings] = useState<SiteSettings | null>(null);

  useEffect(() => {
    fetchSiteSettings();
    const savedKey = localStorage.getItem(STORAGE_KEY);
    if (savedKey) {
      validateStoredKey(savedKey);
    } else {
      setLoading(false);
    }
  }, []);

  const fetchSiteSettings = async () => {
    const { data, error } = await supabase
      .from("site_settings")
      .select("*")
      .limit(1)
      .maybeSingle();

    if (!error && data) {
      setSiteSettings(data as SiteSettings);
    }
  };

  const refreshSiteSettings = async () => {
    await fetchSiteSettings();
  };

  const validateStoredKey = async (keyCode: string) => {
    const { data, error } = await supabase
      .from("access_keys")
      .select("*")
      .eq("key_code", keyCode)
      .eq("is_active", true)
      .maybeSingle();

    if (error || !data) {
      localStorage.removeItem(STORAGE_KEY);
      setAccessKey(null);
    } else {
      const key = data as AccessKey;
      
      // Check if expired
      if (key.expires_at && new Date(key.expires_at) < new Date()) {
        localStorage.removeItem(STORAGE_KEY);
        setAccessKey(null);
      } else if (!key.is_approved && key.pending_approval) {
        // Key is pending approval
        localStorage.removeItem(STORAGE_KEY);
        setAccessKey(null);
      } else {
        setAccessKey(key);
        
        // Update last_used_at
        await supabase
          .from("access_keys")
          .update({ last_used_at: new Date().toISOString() })
          .eq("id", key.id);
      }
    }
    setLoading(false);
  };

  const validateKey = async (keyCode: string): Promise<{ error: string | null }> => {
    // First check site maintenance mode
    const { data: settings } = await supabase
      .from("site_settings")
      .select("maintenance_mode")
      .limit(1)
      .maybeSingle();

    const { data, error } = await supabase
      .from("access_keys")
      .select("*")
      .eq("key_code", keyCode.trim())
      .eq("is_active", true)
      .maybeSingle();

    if (error) {
      return { error: "Erro ao validar chave" };
    }

    if (!data) {
      return { error: "Chave inválida ou inativa" };
    }

    const key = data as AccessKey;

    // Check expiration
    if (key.expires_at && new Date(key.expires_at) < new Date()) {
      return { error: "Esta chave expirou" };
    }

    // Check if pending approval (admins bypass this)
    if (!key.is_admin && key.pending_approval && !key.is_approved) {
      return { error: "Chave pendente de aprovação. Aguarde a liberação do administrador." };
    }

    // Check maintenance mode (admins bypass this)
    if (!key.is_admin && settings?.maintenance_mode) {
      return { error: "Página em manutenção, aguarde até as próximas horas" };
    }

    // Save to localStorage and state
    localStorage.setItem(STORAGE_KEY, keyCode.trim());
    setAccessKey(key);

    // Update last_used_at
    await supabase
      .from("access_keys")
      .update({ last_used_at: new Date().toISOString() })
      .eq("id", key.id);

    return { error: null };
  };

  const signOut = () => {
    localStorage.removeItem(STORAGE_KEY);
    setAccessKey(null);
  };

  const isAdmin = accessKey?.is_admin || false;

  return (
    <AuthContext.Provider value={{ 
      accessKey, 
      loading, 
      isAdmin, 
      siteSettings,
      validateKey, 
      signOut,
      refreshSiteSettings
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
