import { useState, useEffect, useCallback } from "react";
import { Power, RotateCcw, MoreVertical, Trash2, Terminal, Loader2, WifiOff, Link2, FolderOpen, AlertTriangle } from "lucide-react";
import { Button } from "./ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "./ui/dropdown-menu";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

interface ExternalServerCardProps {
  id: string;
  name: string;
  serverUrl: string | null;
  plan?: string;
  onDelete?: () => void;
  onConsole?: () => void;
  onFiles?: () => void;
  onServerStart?: () => void;
  showAdminActions?: boolean;
  ramLimit?: number;
  onRamLimitReached?: () => void;
}

interface ServerStatus {
  ramUsed: number;
  ramTotal: number;
  diskUsed: number;
  diskTotal: number;
}

export function ExternalServerCard({
  id,
  name,
  serverUrl,
  plan,
  onDelete,
  onConsole,
  onFiles,
  onServerStart,
  showAdminActions = false,
  ramLimit,
  onRamLimitReached,
}: ExternalServerCardProps) {
  const [status, setStatus] = useState<"online" | "offline" | "loading">("loading");
  const [serverData, setServerData] = useState<ServerStatus | null>(null);
  const [actionLoading, setActionLoading] = useState<"start" | "stop" | null>(null);

  const fetchStatus = useCallback(async () => {
    if (!serverUrl) {
      setStatus("offline");
      return;
    }

    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 10000);

      const response = await fetch(`${serverUrl}/status`, {
        method: "GET",
        signal: controller.signal,
      });

      clearTimeout(timeoutId);

      if (!response.ok) throw new Error("Server error");

      const data: ServerStatus = await response.json();
      setServerData(data);
      setStatus("online");

      // Check RAM limit
      const ramUsedGB = data.ramUsed / 1024;
      if (ramLimit && ramUsedGB >= ramLimit) {
        toast.error("console.Log: linux_server/server/memory:limite atingido");
        onRamLimitReached?.();
      }
    } catch {
      setStatus("offline");
      setServerData(null);
    }
  }, [serverUrl, ramLimit, onRamLimitReached]);

  useEffect(() => {
    fetchStatus();
    
    const interval = setInterval(fetchStatus, 30000);
    return () => clearInterval(interval);
  }, [fetchStatus]);

  const handleStart = async () => {
    if (!serverUrl) {
      toast.error("URL do servidor não configurada");
      return;
    }

    setActionLoading("start");
    try {
      const response = await fetch(`${serverUrl}/start`, { method: "POST" });
      if (response.ok) {
        toast.success(`Servidor ${name} iniciado!`);
        onServerStart?.();
        await fetchStatus();
      } else {
        toast.error("Falha ao iniciar servidor");
      }
    } catch {
      toast.error("Erro de conexão com o servidor");
    }
    setActionLoading(null);
  };

  const handleStop = async () => {
    if (!serverUrl) {
      toast.error("URL do servidor não configurada");
      return;
    }

    setActionLoading("stop");
    try {
      const response = await fetch(`${serverUrl}/stop`, { method: "POST" });
      if (response.ok) {
        toast.success(`Servidor ${name} parado!`);
        await fetchStatus();
      } else {
        toast.error("Falha ao parar servidor");
      }
    } catch {
      toast.error("Erro de conexão com o servidor");
    }
    setActionLoading(null);
  };

  const handleRestart = async () => {
    await handleStop();
    setTimeout(handleStart, 2000);
  };

  // Convert MB to GB
  const ramUsedGB = serverData ? (serverData.ramUsed / 1024).toFixed(2) : "0.00";
  const ramTotalGB = ramLimit ? ramLimit.toFixed(2) : (serverData ? (serverData.ramTotal / 1024).toFixed(2) : "2.00");
  const storageUsedGB = serverData?.diskUsed?.toFixed(1) || "0.0";
  const storageTotalGB = serverData?.diskTotal?.toFixed(0) || "50";

  const ramPercentage = serverData ? (serverData.ramUsed / 1024 / (ramLimit || serverData.ramTotal / 1024)) * 100 : 0;
  const storagePercentage = serverData ? (serverData.diskUsed / serverData.diskTotal) * 100 : 0;

  const isRamWarning = ramPercentage > 80;
  const isRamCritical = ramPercentage >= 100;

  const isLoading = status === "loading";
  const isOnline = status === "online";
  const isOffline = status === "offline";

  return (
    <div className="glass-card glow-border p-6 space-y-5 animate-fade-in h-full">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          {isLoading ? (
            <Loader2 className="w-4 h-4 animate-spin text-muted-foreground" />
          ) : (
            <div
              className={cn(
                "w-3 h-3 rounded-full",
                isOnline ? "bg-success animate-pulse-glow" : "bg-destructive"
              )}
            />
          )}
          <h3 className="font-semibold text-lg truncate">{name}</h3>
        </div>
        <div className="flex items-center gap-2">
          <span
            className={cn(
              "px-3 py-1 rounded-full text-xs font-medium uppercase tracking-wide",
              isLoading && "bg-muted/50 text-muted-foreground",
              isOnline && "bg-success/20 text-success",
              isOffline && "bg-destructive/20 text-destructive"
            )}
          >
            {isLoading ? "..." : isOnline ? "online" : "offline"}
          </span>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="h-8 w-8">
                <MoreVertical className="w-4 h-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-48 bg-popover border-border">
              <DropdownMenuItem onClick={onFiles}>
                <FolderOpen className="w-4 h-4 mr-2" />
                Files
              </DropdownMenuItem>
              <DropdownMenuItem onClick={onConsole}>
                <Terminal className="w-4 h-4 mr-2" />
                Console
              </DropdownMenuItem>
              <DropdownMenuItem onClick={handleRestart} disabled={isOffline || isLoading}>
                <RotateCcw className="w-4 h-4 mr-2" />
                Reiniciar
              </DropdownMenuItem>
              {showAdminActions && (
                <>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={onDelete} className="text-destructive focus:text-destructive">
                    <Trash2 className="w-4 h-4 mr-2" />
                    Excluir Servidor
                  </DropdownMenuItem>
                </>
              )}
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>

      {/* Server URL Status */}
      {!serverUrl && (
        <div className="flex items-center gap-2 px-3 py-2 rounded-lg bg-warning/10 border border-warning/20">
          <Link2 className="w-4 h-4 text-warning" />
          <span className="text-xs text-warning">URL da VPS não configurada. Contate o administrador.</span>
        </div>
      )}

      {serverUrl && isOffline && (
        <div className="flex items-center gap-2 px-3 py-2 rounded-lg bg-destructive/10 border border-destructive/20">
          <WifiOff className="w-4 h-4 text-destructive" />
          <span className="text-xs text-destructive">Servidor inacessível</span>
        </div>
      )}

      {isRamCritical && (
        <div className="flex items-center gap-2 px-3 py-2 rounded-lg bg-destructive/10 border border-destructive/20">
          <AlertTriangle className="w-4 h-4 text-destructive" />
          <span className="text-xs text-destructive">Limite de RAM atingido! Servidor desligando...</span>
        </div>
      )}

      {/* Controls */}
      <div className="flex gap-2">
        <Button
          variant="success"
          size="default"
          onClick={handleStart}
          className="flex-1"
          disabled={isOnline || isLoading || actionLoading === "start" || !serverUrl}
        >
          {actionLoading === "start" ? (
            <Loader2 className="w-4 h-4 animate-spin" />
          ) : (
            <Power className="w-4 h-4" />
          )}
          Iniciar
        </Button>
        <Button
          variant="destructive"
          size="default"
          onClick={handleStop}
          className="flex-1"
          disabled={isOffline || isLoading || actionLoading === "stop" || !serverUrl}
        >
          {actionLoading === "stop" ? (
            <Loader2 className="w-4 h-4 animate-spin" />
          ) : (
            <Power className="w-4 h-4" />
          )}
          Parar
        </Button>
      </div>

      {/* Stats */}
      <div className="space-y-4">
        {/* RAM */}
        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span className={cn("text-muted-foreground", isRamWarning && "text-warning", isRamCritical && "text-destructive")}>RAM</span>
            <span className={cn("font-mono font-medium", isRamWarning && "text-warning", isRamCritical && "text-destructive")}>
              {ramUsedGB} / {ramTotalGB} GB
            </span>
          </div>
          <div className="progress-bar">
            <div
              className={cn(
                "progress-fill transition-all duration-500",
                isRamWarning && "bg-warning",
                isRamCritical && "bg-destructive"
              )}
              style={{ width: `${Math.min(ramPercentage, 100)}%` }}
            />
          </div>
        </div>

        {/* Storage */}
        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Armazenamento</span>
            <span className="font-mono font-medium">
              {storageUsedGB} / {storageTotalGB} GB
            </span>
          </div>
          <div className="progress-bar">
            <div
              className={cn(
                "progress-fill transition-all duration-500",
                storagePercentage > 80 && "bg-destructive"
              )}
              style={{ width: `${Math.min(storagePercentage, 100)}%` }}
            />
          </div>
        </div>
      </div>

      {/* Plan Badge */}
      {plan && (
        <div className="pt-2 border-t border-border">
          <span className="text-xs text-muted-foreground">Plano: </span>
          <span className="text-xs font-medium text-primary">{plan}</span>
        </div>
      )}

      {/* Auto-refresh indicator */}
      <div className="flex items-center justify-center text-xs text-muted-foreground">
        <div className="w-1.5 h-1.5 rounded-full bg-primary/50 animate-pulse mr-2" />
        Atualização automática: 30s
      </div>
    </div>
  );
}
