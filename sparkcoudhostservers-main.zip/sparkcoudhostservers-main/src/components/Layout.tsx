import { ReactNode } from "react";
import { Sidebar } from "./Sidebar";
import { useAuth } from "@/contexts/AuthContext";
import { Navigate } from "react-router-dom";
import { Loader2, AlertTriangle } from "lucide-react";

interface LayoutProps {
  children: ReactNode;
}

export function Layout({ children }: LayoutProps) {
  const { accessKey, loading, siteSettings, isAdmin } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!accessKey) {
    return <Navigate to="/auth" replace />;
  }

  // Check maintenance mode (admins bypass)
  if (siteSettings?.maintenance_mode && !isAdmin) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background p-4">
        <div className="glass-card p-8 max-w-md text-center">
          <div className="w-16 h-16 mx-auto rounded-full bg-warning/20 flex items-center justify-center mb-4">
            <AlertTriangle className="w-8 h-8 text-warning" />
          </div>
          <h1 className="text-2xl font-bold mb-2">Manutenção</h1>
          <p className="text-muted-foreground">
            Página em manutenção, aguarde até as próximas horas
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Sidebar />
      <main className="ml-64 min-h-screen transition-all duration-300">
        <div className="p-6 lg:p-8">{children}</div>
      </main>
      {/* Background glow effect */}
      <div className="fixed top-0 right-0 w-[600px] h-[600px] pointer-events-none opacity-20">
        <div className="absolute inset-0 bg-gradient-to-bl from-primary/30 via-transparent to-transparent blur-3xl" />
      </div>
    </div>
  );
}
