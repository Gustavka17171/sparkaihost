import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Server, Key, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

export default function Auth() {
  const [keyCode, setKeyCode] = useState("");
  const [loading, setLoading] = useState(false);
  const [siteTitle, setSiteTitle] = useState("LAC HOST");
  const [siteLogo, setSiteLogo] = useState<string | null>(null);
  const [discordLink, setDiscordLink] = useState("https://discord.gg/lachost");
  const { validateKey, accessKey } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (accessKey) {
      navigate("/");
    }
    fetchSiteSettings();
  }, [accessKey, navigate]);

  const fetchSiteSettings = async () => {
    const { data } = await supabase
      .from("site_settings")
      .select("*")
      .limit(1)
      .maybeSingle();

    if (data) {
      setSiteTitle(data.site_title || "LAC HOST");
      setSiteLogo(data.site_logo_url);
      setDiscordLink(data.discord_link || "https://discord.gg/lachost");
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!keyCode.trim()) {
      toast.error("Digite uma chave de acesso");
      return;
    }

    setLoading(true);

    try {
      const { error } = await validateKey(keyCode);
      
      if (error) {
        toast.error(error);
      } else {
        toast.success("Acesso autorizado!");
        navigate("/");
      }
    } catch {
      toast.error("Ocorreu um erro inesperado");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4">
      {/* Background Effects */}
      <div className="fixed inset-0 pointer-events-none">
        <div className="absolute top-0 left-1/4 w-[600px] h-[600px] bg-primary/10 rounded-full blur-[120px]" />
        <div className="absolute bottom-0 right-1/4 w-[400px] h-[400px] bg-accent/10 rounded-full blur-[100px]" />
      </div>

      <div className="w-full max-w-md relative z-10">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-3 mb-4">
            {siteLogo ? (
              <img 
                src={siteLogo} 
                alt={siteTitle}
                className="w-14 h-14 rounded-2xl object-cover shadow-lg"
              />
            ) : (
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-primary to-accent flex items-center justify-center shadow-lg shadow-primary/30">
                <Server className="w-7 h-7 text-primary-foreground" />
              </div>
            )}
          </div>
          <h1 className="text-3xl font-bold">{siteTitle}</h1>
          <p className="text-muted-foreground mt-2">
            Digite sua chave de acesso para continuar
          </p>
        </div>

        {/* Form Card */}
        <div className="glass-card p-8">
          <form onSubmit={handleSubmit} className="space-y-5">
            <div className="space-y-2">
              <Label htmlFor="key">Chave de Acesso</Label>
              <div className="relative">
                <Key className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  id="key"
                  type="text"
                  placeholder="XXXX-XXXX-XXXX-XXXX"
                  value={keyCode}
                  onChange={(e) => setKeyCode(e.target.value.toUpperCase())}
                  className="pl-10 font-mono uppercase tracking-wider"
                  required
                  maxLength={50}
                />
              </div>
              <p className="text-xs text-muted-foreground">
                Solicite sua chave com um administrador
              </p>
            </div>

            <Button
              type="submit"
              variant="glow"
              size="xl"
              className="w-full"
              disabled={loading}
            >
              {loading && <Loader2 className="w-4 h-4 animate-spin" />}
              Acessar Dashboard
            </Button>
          </form>
        </div>

        {/* Features */}
        <div className="mt-8 grid grid-cols-3 gap-4 text-center">
          {[
            { label: "Seguro", desc: "Chaves únicas" },
            { label: "Rápido", desc: "Nosso Discord", link: discordLink },
            { label: "Simples", desc: "Sem cadastro" },
          ].map((feature) => (
            <div key={feature.label} className="p-3 rounded-lg bg-secondary/30">
              <p className="font-semibold text-sm text-primary">{feature.label}</p>
              {feature.link ? (
                <a 
                  href={feature.link}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-xs text-muted-foreground hover:text-primary transition-colors"
                >
                  {feature.desc}
                </a>
              ) : (
                <p className="text-xs text-muted-foreground">{feature.desc}</p>
              )}
            </div>
          ))}
        </div>

        <div className="mt-4 text-center">
          <a 
            href={discordLink}
            target="_blank"
            rel="noopener noreferrer"
            className="text-sm text-primary hover:underline"
          >
            Acesso direto › Visite a gente e tire dúvidas em nosso suporte!
          </a>
        </div>
      </div>
    </div>
  );
}
