import { useState, useEffect } from "react";
import { Layout } from "@/components/Layout";
import { ExternalServerCard } from "@/components/ExternalServerCard";
import { ServerConsole } from "@/components/ServerConsole";
import { FileManager, DEFAULT_SERVER_FILES, FileItem } from "@/components/FileManager";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Plus, Server, FolderOpen } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

interface ServerData {
  id: string;
  name: string;
  server_url: string | null;
  ram_used: number;
  ram_total: number;
}

export default function Servers() {
  const { accessKey } = useAuth();
  const [servers, setServers] = useState<ServerData[]>([]);
  const [loading, setLoading] = useState(true);
  const [createOpen, setCreateOpen] = useState(false);
  const [selectedServer, setSelectedServer] = useState<ServerData | null>(null);
  const [newServerName, setNewServerName] = useState("");
  const [creating, setCreating] = useState(false);
  const [consoleOpen, setConsoleOpen] = useState(false);
  const [filesOpen, setFilesOpen] = useState(false);
  const [serverFiles, setServerFiles] = useState<Record<string, FileItem[]>>({});
  const [editingFile, setEditingFile] = useState<{ serverId: string; file: FileItem; path: string[] } | null>(null);
  const [fileContent, setFileContent] = useState("");

  useEffect(() => {
    fetchServers();

    const channel = supabase
      .channel("my-servers")
      .on("postgres_changes", { event: "*", schema: "public", table: "servers" }, () => {
        fetchServers();
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  const fetchServers = async () => {
    const { data, error } = await supabase
      .from("servers")
      .select("id, name, server_url, ram_used, ram_total")
      .order("created_at", { ascending: false });

    if (error) {
      toast.error("Erro ao carregar servidores");
    } else {
      setServers(data || []);
    }
    setLoading(false);
  };

  const handleCreateServer = async () => {
    if (!newServerName.trim()) {
      toast.error("Digite um nome para o servidor");
      return;
    }

    setCreating(true);

    const { error } = await supabase.from("servers").insert({
      user_id: accessKey?.id || crypto.randomUUID(),
      name: newServerName.trim(),
      server_url: accessKey?.server_url || null,
      ram_total: accessKey?.ram_limit || 2,
      storage_total: accessKey?.storage_limit || 50,
    });

    if (error) {
      toast.error("Erro ao criar servidor");
    } else {
      toast.success("Servidor criado com sucesso!");
      setNewServerName("");
      setCreateOpen(false);
    }

    setCreating(false);
  };

  const handleDelete = async (server: ServerData) => {
    const { error } = await supabase.from("servers").delete().eq("id", server.id);

    if (error) {
      toast.error("Erro ao excluir servidor");
    } else {
      toast.success(`Servidor ${server.name} excluído!`);
    }
  };

  const handleConsole = (server: ServerData) => {
    setSelectedServer(server);
    setConsoleOpen(true);
  };

  const handleFiles = (server: ServerData) => {
    setSelectedServer(server);
    setFilesOpen(true);
  };

  const handleServerStart = async (server: ServerData) => {
    // Create the file structure when server starts
    setServerFiles(prev => ({
      ...prev,
      [server.id]: JSON.parse(JSON.stringify(DEFAULT_SERVER_FILES))
    }));
  };

  const handleRamLimitReached = async (server: ServerData) => {
    // Auto shutdown when RAM limit is reached
    toast.error("console.Log: linux_server/server/memory:limite atingido");
    
    // Try to stop the server via API
    if (server.server_url) {
      try {
        await fetch(`${server.server_url}/stop`, { method: "POST" });
      } catch (e) {
        console.error("Failed to stop server:", e);
      }
    }

    // Update server status in database
    await supabase
      .from("servers")
      .update({ status: "offline" })
      .eq("id", server.id);
  };

  const handleCreateFolder = (serverId: string) => (path: string[], name: string) => {
    setServerFiles(prev => {
      const files = JSON.parse(JSON.stringify(prev[serverId] || []));
      const newFolder: FileItem = { name, type: "folder", children: [] };
      
      if (path.length === 0) {
        files.push(newFolder);
      } else {
        // Navigate to the target folder and add
        let current = files;
        for (const segment of path) {
          const folder = current.find(f => f.name === segment && f.type === "folder");
          if (folder && folder.children) {
            current = folder.children;
          }
        }
        current.push(newFolder);
      }
      
      return { ...prev, [serverId]: files };
    });
    toast.success(`Pasta "${name}" criada`);
  };

  const handleCreateFile = (serverId: string) => (path: string[], name: string) => {
    setServerFiles(prev => {
      const files = JSON.parse(JSON.stringify(prev[serverId] || []));
      const newFile: FileItem = { name, type: "file", size: "0 B" };
      
      if (path.length === 0) {
        files.push(newFile);
      } else {
        let current = files;
        for (const segment of path) {
          const folder = current.find(f => f.name === segment && f.type === "folder");
          if (folder && folder.children) {
            current = folder.children;
          }
        }
        current.push(newFile);
      }
      
      return { ...prev, [serverId]: files };
    });
    toast.success(`Arquivo "${name}" criado`);
  };

  const handleFileClick = (serverId: string) => (file: FileItem) => {
    if (file.type === "file" && (file.name.endsWith(".txt") || file.name.endsWith(".cfg") || file.name.endsWith(".config"))) {
      setEditingFile({ serverId, file, path: [] });
      setFileContent("# Conteúdo do arquivo\n# Edite aqui...");
    }
  };

  const handleDeleteFile = (serverId: string) => (path: string[], fileName: string) => {
    setServerFiles(prev => {
      const files = JSON.parse(JSON.stringify(prev[serverId] || []));
      
      if (path.length === 0) {
        const index = files.findIndex((f: FileItem) => f.name === fileName);
        if (index > -1) files.splice(index, 1);
      } else {
        let current = files;
        for (const segment of path) {
          const folder = current.find((f: FileItem) => f.name === segment && f.type === "folder");
          if (folder && folder.children) {
            current = folder.children;
          }
        }
        const index = current.findIndex((f: FileItem) => f.name === fileName);
        if (index > -1) current.splice(index, 1);
      }
      
      return { ...prev, [serverId]: files };
    });
    toast.success(`"${fileName}" excluído`);
  };

  const handleSaveFile = () => {
    if (editingFile) {
      toast.success(`Arquivo "${editingFile.file.name}" salvo`);
      setEditingFile(null);
    }
  };

  return (
    <Layout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between animate-slide-up">
          <div>
            <h1 className="text-2xl lg:text-3xl font-bold">Meus Servidores</h1>
            <p className="text-muted-foreground mt-1">
              Gerencie todos os seus servidores LAC
            </p>
          </div>
          <Dialog open={createOpen} onOpenChange={setCreateOpen}>
            <DialogTrigger asChild>
              <Button variant="glow">
                <Plus className="w-4 h-4" />
                Novo Servidor
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Criar Novo Servidor</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="serverName">Nome do Servidor</Label>
                  <Input
                    id="serverName"
                    placeholder="Meu Servidor LAC"
                    value={newServerName}
                    onChange={(e) => setNewServerName(e.target.value)}
                    maxLength={50}
                  />
                </div>
                <div className="glass-card p-4 bg-secondary/20">
                  <div className="flex items-center gap-2 mb-2">
                    <FolderOpen className="w-4 h-4 text-warning" />
                    <span className="text-sm font-medium">Estrutura de Arquivos</span>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    A estrutura será criada automaticamente ao iniciar: .config/unity3d/MA/LAC
                  </p>
                </div>
                {accessKey?.server_url && (
                  <div className="p-3 rounded-lg bg-primary/10 border border-primary/20">
                    <p className="text-xs text-muted-foreground">
                      VPS configurada: <span className="text-primary">{accessKey.server_url}</span>
                    </p>
                  </div>
                )}
                <div className="p-3 rounded-lg bg-secondary/50">
                  <p className="text-xs text-muted-foreground">
                    Limites: RAM {accessKey?.ram_limit || 2}GB | Storage {accessKey?.storage_limit || 50}GB
                  </p>
                </div>
                <Button
                  variant="glow"
                  className="w-full"
                  onClick={handleCreateServer}
                  disabled={creating}
                >
                  {creating ? "Criando..." : "Criar Servidor"}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {/* Server Grid */}
        {loading ? (
          <div className="glass-card p-12 text-center">
            <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin mx-auto" />
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-4">
            {servers.map((server) => (
              <ExternalServerCard
                key={server.id}
                id={server.id}
                name={server.name}
                serverUrl={server.server_url}
                showAdminActions
                onDelete={() => handleDelete(server)}
                onConsole={() => handleConsole(server)}
                onFiles={() => handleFiles(server)}
                onServerStart={() => handleServerStart(server)}
                ramLimit={accessKey?.ram_limit}
                onRamLimitReached={() => handleRamLimitReached(server)}
              />
            ))}

            {/* Empty State Card */}
            <div
              className="glass-card p-6 flex flex-col items-center justify-center min-h-[280px] border-dashed animate-fade-in cursor-pointer hover:bg-secondary/20 transition-colors"
              onClick={() => setCreateOpen(true)}
            >
              <div className="w-12 h-12 rounded-full bg-secondary flex items-center justify-center mb-4">
                <Plus className="w-6 h-6 text-muted-foreground" />
              </div>
              <p className="text-muted-foreground text-center">Criar novo servidor</p>
              <p className="text-xs text-muted-foreground mt-1">
                {servers.length} servidores
              </p>
            </div>
          </div>
        )}

        {servers.length === 0 && !loading && (
          <div className="glass-card p-12 text-center">
            <Server className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
            <h3 className="font-semibold text-lg">Nenhum servidor ainda</h3>
            <p className="text-muted-foreground mt-1 mb-4">
              Crie seu primeiro servidor para começar
            </p>
            <Button variant="glow" onClick={() => setCreateOpen(true)}>
              <Plus className="w-4 h-4" />
              Criar Servidor
            </Button>
          </div>
        )}

        {/* Info */}
        <div className="glass-card p-6 animate-fade-in">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-semibold">Acesso: {accessKey?.name || "Usuário"}</h3>
              <p className="text-sm text-muted-foreground mt-1">
                {accessKey?.is_admin ? "Administrador" : "Usuário"} • RAM: {accessKey?.ram_limit || 2}GB • Storage: {accessKey?.storage_limit || 50}GB
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Server Console */}
      <ServerConsole
        serverName={selectedServer?.name || ""}
        serverUrl={selectedServer?.server_url || null}
        isOpen={consoleOpen}
        onClose={() => setConsoleOpen(false)}
      />

      {/* Files Dialog */}
      <Dialog open={filesOpen} onOpenChange={setFilesOpen}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <FolderOpen className="w-5 h-5 text-warning" />
              Files - {selectedServer?.name}
            </DialogTitle>
          </DialogHeader>
          <div className="py-4">
            <FileManager 
              files={selectedServer ? (serverFiles[selectedServer.id] || []) : []}
              onFileClick={selectedServer ? handleFileClick(selectedServer.id) : undefined}
              onCreateFolder={selectedServer ? handleCreateFolder(selectedServer.id) : undefined}
              onCreateFile={selectedServer ? handleCreateFile(selectedServer.id) : undefined}
              onDeleteFile={selectedServer ? handleDeleteFile(selectedServer.id) : undefined}
            />
          </div>
        </DialogContent>
      </Dialog>

      {/* File Editor Dialog */}
      <Dialog open={!!editingFile} onOpenChange={() => setEditingFile(null)}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Editando: {editingFile?.file.name}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <textarea
              value={fileContent}
              onChange={(e) => setFileContent(e.target.value)}
              className="w-full h-64 p-4 rounded-lg bg-secondary/50 border border-border font-mono text-sm resize-none focus:outline-none focus:ring-2 focus:ring-primary"
              placeholder="Conteúdo do arquivo..."
            />
            <div className="flex gap-2 justify-end">
              <Button variant="outline" onClick={() => setEditingFile(null)}>
                Cancelar
              </Button>
              <Button variant="glow" onClick={handleSaveFile}>
                Salvar
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </Layout>
  );
}
