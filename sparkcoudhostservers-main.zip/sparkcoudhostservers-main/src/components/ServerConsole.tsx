import { useEffect, useRef, useState, useCallback } from "react";
import { Terminal, X, Maximize2, Minimize2, RefreshCw } from "lucide-react";
import { Button } from "./ui/button";
import { cn } from "@/lib/utils";

interface LogEntry {
  id: string;
  message: string;
  type: "info" | "warning" | "error" | "success";
  timestamp: Date;
}

interface ServerConsoleProps {
  serverName: string;
  serverUrl: string | null;
  isOpen: boolean;
  onClose: () => void;
}

export function ServerConsole({ serverName, serverUrl, isOpen, onClose }: ServerConsoleProps) {
  const scrollRef = useRef<HTMLDivElement>(null);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [autoScroll, setAutoScroll] = useState(true);

  const fetchLogs = useCallback(async () => {
    if (!serverUrl) {
      setError("URL do servidor não configurada");
      return;
    }

    try {
      const response = await fetch(`${serverUrl}/logs`, {
        method: "GET",
        headers: { "Content-Type": "application/json" },
      });

      if (!response.ok) {
        throw new Error(`Erro ao buscar logs: ${response.status}`);
      }

      const data = await response.json();
      
      // Normalize API response to LogEntry format
      const newLogs: LogEntry[] = (data.logs || data || []).map((log: any, index: number) => ({
        id: log.id || `${Date.now()}-${index}`,
        message: log.message || log.text || String(log),
        type: normalizeLogType(log.type || log.level || "info"),
        timestamp: log.timestamp ? new Date(log.timestamp) : new Date(),
      }));

      setLogs(newLogs);
      setError(null);
    } catch (err) {
      console.error("Erro ao buscar logs:", err);
      setError(err instanceof Error ? err.message : "Erro desconhecido");
    }
  }, [serverUrl]);

  const normalizeLogType = (type: string): "info" | "warning" | "error" | "success" => {
    const lowerType = type.toLowerCase();
    if (lowerType.includes("error") || lowerType.includes("err")) return "error";
    if (lowerType.includes("warn")) return "warning";
    if (lowerType.includes("success") || lowerType.includes("ok")) return "success";
    return "info";
  };

  // Initial fetch and polling
  useEffect(() => {
    if (!isOpen || !serverUrl) return;

    setIsLoading(true);
    fetchLogs().finally(() => setIsLoading(false));

    const interval = setInterval(fetchLogs, 2000); // Poll every 2 seconds

    return () => clearInterval(interval);
  }, [isOpen, serverUrl, fetchLogs]);

  // Auto-scroll to bottom
  useEffect(() => {
    if (autoScroll && scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [logs, autoScroll]);

  const handleScroll = () => {
    if (!scrollRef.current) return;
    const { scrollTop, scrollHeight, clientHeight } = scrollRef.current;
    const isAtBottom = scrollHeight - scrollTop - clientHeight < 50;
    setAutoScroll(isAtBottom);
  };

  if (!isOpen) return null;

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit", second: "2-digit" });
  };

  return (
    <div
      className={cn(
        "fixed z-50 bg-background/95 backdrop-blur-xl border border-border rounded-xl shadow-2xl flex flex-col",
        isFullscreen
          ? "inset-4"
          : "bottom-4 right-4 w-[600px] h-[400px]"
      )}
    >
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-border bg-card rounded-t-xl">
        <div className="flex items-center gap-3">
          <div className="p-1.5 rounded-lg bg-primary/20">
            <Terminal className="w-4 h-4 text-primary" />
          </div>
          <div>
            <h3 className="font-semibold text-sm">{serverName}</h3>
            <p className="text-xs text-muted-foreground">Console do Servidor</p>
          </div>
        </div>
        <div className="flex items-center gap-1">
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8"
            onClick={() => fetchLogs()}
            disabled={isLoading}
          >
            <RefreshCw className={cn("w-4 h-4", isLoading && "animate-spin")} />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8"
            onClick={() => setIsFullscreen(!isFullscreen)}
          >
            {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
          </Button>
          <Button variant="ghost" size="icon" className="h-8 w-8" onClick={onClose}>
            <X className="w-4 h-4" />
          </Button>
        </div>
      </div>

      {/* Console Output */}
      <div
        ref={scrollRef}
        onScroll={handleScroll}
        className="flex-1 overflow-y-auto p-4 font-mono text-xs space-y-1 bg-[hsl(222,47%,5%)]"
      >
        {!serverUrl && (
          <div className="text-warning">⚠ URL do servidor não configurada. Configure nas configurações do servidor.</div>
        )}
        
        {error && (
          <div className="text-destructive">✗ {error}</div>
        )}

        {isLoading && logs.length === 0 && (
          <div className="text-muted-foreground animate-pulse">Carregando logs...</div>
        )}

        {logs.length === 0 && !isLoading && !error && serverUrl && (
          <div className="text-muted-foreground">Nenhum log disponível.</div>
        )}

        {logs.map((log) => (
          <div key={log.id} className="flex gap-2">
            <span className="text-muted-foreground shrink-0">[{formatTime(log.timestamp)}]</span>
            <span
              className={cn(
                log.type === "info" && "text-foreground/80",
                log.type === "success" && "text-success",
                log.type === "warning" && "text-warning",
                log.type === "error" && "text-destructive"
              )}
            >
              {log.message}
            </span>
          </div>
        ))}
        
        <div className="flex items-center gap-1 text-primary animate-pulse">
          <span>▌</span>
        </div>
      </div>

      {/* Footer with status */}
      <div className="px-4 py-2 border-t border-border bg-card rounded-b-xl flex items-center justify-between text-xs text-muted-foreground">
        <span>{logs.length} logs</span>
        <span className="flex items-center gap-1">
          <span className={cn("w-2 h-2 rounded-full", serverUrl ? "bg-success animate-pulse" : "bg-muted")} />
          {serverUrl ? "Atualizando a cada 2s" : "Desconectado"}
        </span>
      </div>
    </div>
  );
}