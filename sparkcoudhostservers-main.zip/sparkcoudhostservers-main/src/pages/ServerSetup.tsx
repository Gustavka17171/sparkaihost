import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Server, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

export default function ServerSetup() {
  const { accessKey } = useAuth();
  const navigate = useNavigate();
  const [serverName, setServerName] = useState("");
  const [loading, setLoading] = useState(false);

  const handleCreate = async () => {
    if (!serverName.trim()) {
      toast.error("Digite um nome para o servidor");
      return;
    }

    setLoading(true);

    const { error } = await supabase.from("servers").insert({
      user_id: accessKey?.id || crypto.randomUUID(),
      name: serverName.trim(),
      server_url: accessKey?.server_url || null,
    });

    if (error) {
      toast.error("Erro ao criar servidor");
    } else {
      toast.success("Servidor criado com sucesso!");
      navigate("/servers");
    }

    setLoading(false);
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      {/* Background effects */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/20 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-primary/10 rounded-full blur-3xl" />
      </div>

      <div className="glass-card w-full max-w-md p-8 animate-fade-in relative z-10">
        <div className="text-center mb-8">
          <div className="w-16 h-16 mx-auto rounded-xl bg-gradient-to-br from-primary to-primary/50 flex items-center justify-center mb-4">
            <Server className="w-8 h-8 text-primary-foreground" />
          </div>
          <h1 className="text-2xl font-bold">Configure seu Servidor</h1>
          <p className="text-muted-foreground mt-2">
            Dê um nome para seu servidor LAC
          </p>
        </div>

        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="serverName">Nome do Servidor</Label>
            <Input
              id="serverName"
              placeholder="Ex: Meu Servidor LAC"
              value={serverName}
              onChange={(e) => setServerName(e.target.value)}
              maxLength={50}
              disabled={loading}
            />
          </div>

          <Button 
            variant="glow" 
            className="w-full" 
            onClick={handleCreate}
            disabled={loading || !serverName.trim()}
          >
            {loading ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <>
                <Server className="w-4 h-4" />
                Criar Servidor
              </>
            )}
          </Button>

          <Button 
            variant="outline" 
            className="w-full" 
            onClick={() => navigate("/servers")}
            disabled={loading}
          >
            Pular por agora
          </Button>
        </div>

        <div className="mt-6 p-4 rounded-lg bg-secondary/50">
          <p className="text-sm text-muted-foreground text-center">
            Você pode alterar o nome do servidor depois nas configurações.
          </p>
        </div>
      </div>
    </div>
  );
}
