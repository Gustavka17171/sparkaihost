import { useState, useEffect } from "react";
import { Server, HardDrive, Activity } from "lucide-react";
import { Layout } from "@/components/Layout";
import { ExternalServerCard } from "@/components/ExternalServerCard";
import { StatCard } from "@/components/StatCard";
import { ServerConsole } from "@/components/ServerConsole";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

interface ServerData {
  id: string;
  name: string;
  server_url: string | null;
}

export default function Dashboard() {
  const { accessKey } = useAuth();
  const [servers, setServers] = useState<ServerData[]>([]);
  const [loading, setLoading] = useState(true);
  const [consoleOpen, setConsoleOpen] = useState(false);
  const [selectedServer, setSelectedServer] = useState<ServerData | null>(null);

  useEffect(() => {
    fetchServers();

    const channel = supabase
      .channel("servers-changes")
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "servers" },
        () => {
          fetchServers();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  const fetchServers = async () => {
    const { data, error } = await supabase
      .from("servers")
      .select("id, name, server_url")
      .order("created_at", { ascending: false });

    if (error) {
      toast.error("Erro ao carregar servidores");
    } else {
      setServers(data || []);
    }
    setLoading(false);
  };

  const handleConsole = (server: ServerData) => {
    setSelectedServer(server);
    setConsoleOpen(true);
  };

  const handleDelete = async (server: ServerData) => {
    const { error } = await supabase.from("servers").delete().eq("id", server.id);
    if (error) {
      toast.error("Erro ao excluir servidor");
    } else {
      toast.success(`Servidor ${server.name} excluído!`);
    }
  };

  return (
    <Layout>
      <div className="space-y-6">
        {/* Header */}
        <div className="animate-slide-up">
          <h1 className="text-2xl lg:text-3xl font-bold">Dashboard</h1>
          <p className="text-muted-foreground mt-1">
            Bem-vindo, {accessKey?.name || "Usuário"}!
          </p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 lg:grid-cols-3 gap-4">
          <StatCard
            title="Servidores"
            value={servers.length}
            subtitle="servidores conectados"
            icon={Server}
            variant="success"
          />
          <StatCard
            title="Tipo de Acesso"
            value={accessKey?.is_admin ? "Admin" : "Usuário"}
            subtitle="nível de permissão"
            icon={Activity}
            variant="default"
          />
          <StatCard
            title="Status"
            value="Ativo"
            subtitle="chave válida"
            icon={HardDrive}
            variant="warning"
          />
        </div>

        {/* Servers Section */}
        <div className="space-y-4">
          <h2 className="text-xl font-semibold">Seus Servidores</h2>

          {loading ? (
            <div className="glass-card p-12 text-center">
              <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin mx-auto" />
              <p className="text-muted-foreground mt-4">Carregando servidores...</p>
            </div>
          ) : servers.length === 0 ? (
            <div className="glass-card p-12 text-center">
              <Server className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
              <h3 className="font-semibold text-lg">Nenhum servidor ainda</h3>
              <p className="text-muted-foreground mt-1">
                Vá para "Meus Servidores" para criar seu primeiro servidor
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-4">
              {servers.map((server) => (
                <ExternalServerCard
                  key={server.id}
                  id={server.id}
                  name={server.name}
                  serverUrl={server.server_url}
                  onConsole={() => handleConsole(server)}
                  onDelete={() => handleDelete(server)}
                  showAdminActions
                />
              ))}
            </div>
          )}
        </div>

        {/* Info Card */}
        <div className="glass-card p-6 animate-fade-in">
          <h3 className="font-semibold mb-2">Como funciona?</h3>
          <p className="text-sm text-muted-foreground">
            Seu painel se conecta diretamente à API do seu servidor VPS. Os dados de RAM e armazenamento 
            são atualizados automaticamente a cada 30 segundos. Configure a URL do servidor nas 
            configurações para começar.
          </p>
        </div>
      </div>

      {/* Server Console */}
      <ServerConsole
        serverName={selectedServer?.name || ""}
        serverUrl={selectedServer?.server_url || null}
        isOpen={consoleOpen}
        onClose={() => setConsoleOpen(false)}
      />
    </Layout>
  );
}
