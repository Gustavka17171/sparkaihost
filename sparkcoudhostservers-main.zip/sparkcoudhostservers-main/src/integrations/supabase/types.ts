export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.1"
  }
  public: {
    Tables: {
      access_keys: {
        Row: {
          created_at: string | null
          created_by: string | null
          current_devices: number | null
          expires_at: string | null
          id: string
          is_active: boolean | null
          is_admin: boolean | null
          is_approved: boolean | null
          key_code: string
          last_used_at: string | null
          max_devices: number | null
          name: string | null
          pending_approval: boolean | null
          ram_limit: number | null
          server_url: string | null
          storage_limit: number | null
        }
        Insert: {
          created_at?: string | null
          created_by?: string | null
          current_devices?: number | null
          expires_at?: string | null
          id?: string
          is_active?: boolean | null
          is_admin?: boolean | null
          is_approved?: boolean | null
          key_code: string
          last_used_at?: string | null
          max_devices?: number | null
          name?: string | null
          pending_approval?: boolean | null
          ram_limit?: number | null
          server_url?: string | null
          storage_limit?: number | null
        }
        Update: {
          created_at?: string | null
          created_by?: string | null
          current_devices?: number | null
          expires_at?: string | null
          id?: string
          is_active?: boolean | null
          is_admin?: boolean | null
          is_approved?: boolean | null
          key_code?: string
          last_used_at?: string | null
          max_devices?: number | null
          name?: string | null
          pending_approval?: boolean | null
          ram_limit?: number | null
          server_url?: string | null
          storage_limit?: number | null
        }
        Relationships: []
      }
      map_uploads: {
        Row: {
          created_at: string | null
          destination_url: string | null
          file_name: string
          file_size: number
          id: string
          server_id: string | null
          status: string | null
          user_id: string
        }
        Insert: {
          created_at?: string | null
          destination_url?: string | null
          file_name: string
          file_size: number
          id?: string
          server_id?: string | null
          status?: string | null
          user_id: string
        }
        Update: {
          created_at?: string | null
          destination_url?: string | null
          file_name?: string
          file_size?: number
          id?: string
          server_id?: string | null
          status?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "map_uploads_server_id_fkey"
            columns: ["server_id"]
            isOneToOne: false
            referencedRelation: "servers"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          created_at: string | null
          email: string | null
          id: string
          is_admin: boolean | null
          max_servers: number | null
          name: string | null
          plan: string | null
          ram_limit: number | null
          storage_limit: number | null
          updated_at: string | null
          user_id: string
        }
        Insert: {
          created_at?: string | null
          email?: string | null
          id?: string
          is_admin?: boolean | null
          max_servers?: number | null
          name?: string | null
          plan?: string | null
          ram_limit?: number | null
          storage_limit?: number | null
          updated_at?: string | null
          user_id: string
        }
        Update: {
          created_at?: string | null
          email?: string | null
          id?: string
          is_admin?: boolean | null
          max_servers?: number | null
          name?: string | null
          plan?: string | null
          ram_limit?: number | null
          storage_limit?: number | null
          updated_at?: string | null
          user_id?: string
        }
        Relationships: []
      }
      server_logs: {
        Row: {
          created_at: string | null
          id: string
          message: string
          server_id: string
          type: string | null
        }
        Insert: {
          created_at?: string | null
          id?: string
          message: string
          server_id: string
          type?: string | null
        }
        Update: {
          created_at?: string | null
          id?: string
          message?: string
          server_id?: string
          type?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "server_logs_server_id_fkey"
            columns: ["server_id"]
            isOneToOne: false
            referencedRelation: "servers"
            referencedColumns: ["id"]
          },
        ]
      }
      servers: {
        Row: {
          created_at: string | null
          id: string
          max_players: number | null
          name: string
          players_online: number | null
          ram_total: number | null
          ram_used: number | null
          server_url: string | null
          status: string | null
          storage_total: number | null
          storage_used: number | null
          updated_at: string | null
          user_id: string
        }
        Insert: {
          created_at?: string | null
          id?: string
          max_players?: number | null
          name: string
          players_online?: number | null
          ram_total?: number | null
          ram_used?: number | null
          server_url?: string | null
          status?: string | null
          storage_total?: number | null
          storage_used?: number | null
          updated_at?: string | null
          user_id: string
        }
        Update: {
          created_at?: string | null
          id?: string
          max_players?: number | null
          name?: string
          players_online?: number | null
          ram_total?: number | null
          ram_used?: number | null
          server_url?: string | null
          status?: string | null
          storage_total?: number | null
          storage_used?: number | null
          updated_at?: string | null
          user_id?: string
        }
        Relationships: []
      }
      site_settings: {
        Row: {
          auto_approve_keys: boolean | null
          discord_link: string | null
          id: string
          maintenance_mode: boolean | null
          site_logo_url: string | null
          site_title: string | null
          updated_at: string | null
        }
        Insert: {
          auto_approve_keys?: boolean | null
          discord_link?: string | null
          id?: string
          maintenance_mode?: boolean | null
          site_logo_url?: string | null
          site_title?: string | null
          updated_at?: string | null
        }
        Update: {
          auto_approve_keys?: boolean | null
          discord_link?: string | null
          id?: string
          maintenance_mode?: boolean | null
          site_logo_url?: string | null
          site_title?: string | null
          updated_at?: string | null
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      is_admin_key: { Args: { user_key: string }; Returns: boolean }
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
